# Content-addressed cache design for Dafny issue 261

This archive contains a design/proposal patch, standalone C# proposal patches,
standard-library Python models, a source option audit, and validation notes.
It contains no repository snapshot. The C# proposals are not applied by the
documentation patch and have not been compiled.

Read docs/dev/design/261-content-addressed-caches.md.
Run: python3 docs/dev/design/261/models/run_models.py
Expected: 57 passing test methods (11 task, 14 DAG, 12 naming, 20 storage).
Python 3.10 or newer; the storage model uses POSIX file publication.

Apply the design patch to Dafny commit
428e348b0b125cb67505f03a0026b3f497f98e48 with:
  git apply 261-documentation.patch

The independent C# proposals are under docs/dev/design/261/patches/.
Check them without changing product files:
  git apply --check docs/dev/design/261/patches/history-free-translation.patch docs/dev/design/261/patches/content-resolution.patch

The documentation patch omits this archive to avoid recursive embedding.
MANIFEST.sha256 covers every other member of this archive.
