(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@24 (T@T T@U) T@U)
(declare-fun $generated@@25 () T@T)
(declare-fun $generated@@28 (Real) Real)
(declare-fun $generated@@31 (T@T T@U) T@U)
(declare-fun $generated@@34 (T@U T@U) Bool)
(declare-fun $generated@@35 (T@T T@U T@U) Bool)
(declare-fun $generated@@37 (T@T T@T) T@T)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@T) T@T)
(declare-fun $generated@@41 (T@T) T@T)
(declare-fun $generated@@64 (T@U T@U T@U) Bool)
(declare-fun $generated@@65 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@80 () T@U)
(declare-fun $generated@@82 (T@U T@U) T@U)
(declare-fun $generated@@91 (T@U Real) Bool)
(declare-fun $generated@@92 (T@U Real) Bool)
(declare-fun $generated@@102 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@103 () T@T)
(declare-fun $generated@@104 () T@T)
(declare-fun $generated@@105 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@106 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@22 T@U) ($generated@@23 T@T) ) (! (= ($generated@@21 $generated@@23 $generated@@22) $generated@@22)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@21 $generated@@23 $generated@@22))
)))
(assert (= ($generated@@3 $generated@@25) 3))
(assert (forall (($generated@@26 T@U) ($generated@@27 T@T) ) (! (= ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)) ($generated@@21 $generated@@25 ($generated@@24 $generated@@27 $generated@@26)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)))
)))
(assert (forall (($generated@@29 Real) ) (! (= ($generated@@28 $generated@@29) $generated@@29)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@28 $generated@@29))
)))
(assert (forall (($generated@@30 Real) ) (! (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))) ($generated@@21 $generated@@25 ($generated@@24 $generated@@6 ($generated@@11 $generated@@30))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@T) ) (! (= ($generated@@31 $generated@@33 ($generated@@24 $generated@@33 $generated@@32)) $generated@@32)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@24 $generated@@33 $generated@@32))
)))
(assert (forall (($generated@@36 T@U) ) (!  (=> ($generated@@34 $generated@@36 $generated) (and (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36)))) $generated@@36) ($generated@@35 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@34 $generated@@36 $generated))
)))
(assert  (and (and (and (and (forall (($generated@@42 T@T) ($generated@@43 T@T) ($generated@@44 T@U) ($generated@@45 T@U) ($generated@@46 T@U) ) (! (= ($generated@@38 $generated@@42 $generated@@43 ($generated@@39 $generated@@42 $generated@@43 $generated@@45 $generated@@46 $generated@@44) $generated@@46) $generated@@44)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@47 T@T) ($generated@@48 T@T) ($generated@@49 T@U) ($generated@@50 T@U) ($generated@@51 T@U) ($generated@@52 T@U) ) (!  (or (= $generated@@51 $generated@@52) (= ($generated@@38 $generated@@47 $generated@@48 ($generated@@39 $generated@@47 $generated@@48 $generated@@50 $generated@@51 $generated@@49) $generated@@52) ($generated@@38 $generated@@47 $generated@@48 $generated@@50 $generated@@52)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@3 ($generated@@37 $generated@@53 $generated@@54)) 4)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@40 ($generated@@37 $generated@@55 $generated@@56)) $generated@@55)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@37 $generated@@55 $generated@@56))
))) (forall (($generated@@57 T@T) ($generated@@58 T@T) ) (! (= ($generated@@41 ($generated@@37 $generated@@57 $generated@@58)) $generated@@58)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@37 $generated@@57 $generated@@58))
))))
(assert (forall (($generated@@59 T@U) ($generated@@60 T@U) ) (!  (=> ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)) (and (= ($generated@@24 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59)) $generated@@59) ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59) ($generated@@17 $generated@@60))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)))
)))
(assert (forall (($generated@@61 T@U) ($generated@@62 T@U) ($generated@@63 T@T) ) (! (= ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62) ($generated@@35 $generated@@63 $generated@@61 $generated@@62))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 T@U) ($generated@@68 T@U) ($generated@@69 T@T) ) (! (= ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68) ($generated@@65 $generated@@69 $generated@@66 $generated@@67 $generated@@68))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68))
)))
(assert (forall (($generated@@70 Real) ) (! ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated))
)))
(assert (forall (($generated@@71 T@U) ($generated@@72 T@U) ) (! (= ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)) (forall (($generated@@73 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73)) ($generated@@34 $generated@@73 $generated@@72))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (! ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74))
)))
(assert (forall (($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ) (! (= ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78) (forall (($generated@@79 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79)) ($generated@@64 $generated@@79 $generated@@77 $generated@@78))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78))
)))
(assert (forall (($generated@@81 T@U) ) (!  (not ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81)))
 :qid |DafnyPreludebpl.837:15|
 :skolemid |155|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81))
)))
(assert (forall (($generated@@83 T@U) ($generated@@84 T@U) ($generated@@85 T@U) ) (! (= ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@83 $generated@@84) $generated@@85))  (or (= $generated@@85 $generated@@84) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@83 $generated@@85))))
 :qid |DafnyPreludebpl.845:15|
 :skolemid |157|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@83 $generated@@84) $generated@@85))
)))
(assert (forall (($generated@@86 T@U) ($generated@@87 T@U) ) (! ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@86 $generated@@87) $generated@@87))
 :qid |DafnyPreludebpl.847:15|
 :skolemid |158|
 :pattern ( ($generated@@82 $generated@@86 $generated@@87))
)))
(assert (forall (($generated@@88 T@U) ($generated@@89 T@U) ($generated@@90 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@88 $generated@@90)) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@88 $generated@@89) $generated@@90)))
 :qid |DafnyPreludebpl.849:15|
 :skolemid |159|
 :pattern ( ($generated@@82 $generated@@88 $generated@@89) ($generated@@38 $generated@@25 $generated@@4 $generated@@88 $generated@@90))
)))
(assert (forall (($generated@@93 T@U) ($generated@@94 Real) ) (!  (=> ($generated@@92 $generated@@93 $generated@@94) (= ($generated@@91 $generated@@93 $generated@@94) (forall (($generated@@95 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@93 ($generated@@24 $generated@@6 ($generated@@11 $generated@@95)))) (<= $generated@@95 $generated@@94))
 :qid |realcompletenessdfy.199:10|
 :skolemid |578|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@93 ($generated@@24 $generated@@6 ($generated@@11 $generated@@95))))
))))
 :qid |realcompletenessdfy.198:23|
 :skolemid |579|
 :pattern ( ($generated@@91 $generated@@93 $generated@@94))
)))
(assert (forall (($generated@@96 T@U) ($generated@@97 Real) ) (!  (=> ($generated@@92 $generated@@96 ($generated@@28 $generated@@97)) (= ($generated@@91 $generated@@96 ($generated@@28 $generated@@97)) (forall (($generated@@98 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@96 ($generated@@24 $generated@@6 ($generated@@11 $generated@@98)))) (<= $generated@@98 ($generated@@28 $generated@@97)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |580|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@96 ($generated@@24 $generated@@6 ($generated@@11 $generated@@98))))
))))
 :qid |realcompletenessdfy.198:23|
 :weight 3
 :skolemid |581|
 :pattern ( ($generated@@91 $generated@@96 ($generated@@28 $generated@@97)))
)))
(assert (forall (($generated@@99 T@U) ($generated@@100 Real) ) (!  (=> ($generated@@92 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@28 $generated@@100)) (= ($generated@@91 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@28 $generated@@100)) (forall (($generated@@101 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@24 $generated@@6 ($generated@@11 $generated@@101)))) (<= $generated@@101 ($generated@@28 $generated@@100)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |582|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@99 ($generated@@24 $generated@@6 ($generated@@11 $generated@@101))))
))))
 :qid |realcompletenessdfy.198:23|
 :weight 3
 :skolemid |583|
 :pattern ( ($generated@@91 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@28 $generated@@100)))
)))
(assert  (and (and (and (forall (($generated@@107 T@T) ($generated@@108 T@T) ($generated@@109 T@T) ($generated@@110 T@U) ($generated@@111 T@U) ($generated@@112 T@U) ($generated@@113 T@U) ) (! (= ($generated@@102 $generated@@107 $generated@@108 $generated@@109 ($generated@@106 $generated@@107 $generated@@108 $generated@@109 $generated@@111 $generated@@112 $generated@@113 $generated@@110) $generated@@112 $generated@@113) $generated@@110)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@114 T@T) ($generated@@115 T@T) ($generated@@116 T@T) ($generated@@117 T@U) ($generated@@118 T@U) ($generated@@119 T@U) ($generated@@120 T@U) ($generated@@121 T@U) ($generated@@122 T@U) ) (!  (or (= $generated@@119 $generated@@121) (= ($generated@@102 $generated@@114 $generated@@115 $generated@@116 ($generated@@106 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@119 $generated@@120 $generated@@117) $generated@@121 $generated@@122) ($generated@@102 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@121 $generated@@122)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@123 T@T) ($generated@@124 T@T) ($generated@@125 T@T) ($generated@@126 T@U) ($generated@@127 T@U) ($generated@@128 T@U) ($generated@@129 T@U) ($generated@@130 T@U) ($generated@@131 T@U) ) (!  (or (= $generated@@129 $generated@@131) (= ($generated@@102 $generated@@123 $generated@@124 $generated@@125 ($generated@@106 $generated@@123 $generated@@124 $generated@@125 $generated@@127 $generated@@128 $generated@@129 $generated@@126) $generated@@130 $generated@@131) ($generated@@102 $generated@@123 $generated@@124 $generated@@125 $generated@@127 $generated@@130 $generated@@131)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@103) 5)) (= ($generated@@3 $generated@@104) 6)))
(assert (forall (($generated@@132 T@U) ($generated@@133 T@U) ($generated@@134 T@U) ($generated@@135 Bool) ($generated@@136 T@U) ($generated@@137 T@U) ) (! (= ($generated@@8 ($generated@@102 $generated@@103 $generated@@104 $generated@@4 ($generated@@105 $generated@@132 $generated@@133 $generated@@134 $generated@@135) $generated@@136 $generated@@137))  (=> (and (or (not (= $generated@@136 $generated@@132)) (not true)) ($generated@@8 ($generated@@31 $generated@@4 ($generated@@38 $generated@@104 $generated@@25 ($generated@@38 $generated@@103 ($generated@@37 $generated@@104 $generated@@25) $generated@@133 $generated@@136) $generated@@134)))) $generated@@135))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |604|
 :pattern ( ($generated@@102 $generated@@103 $generated@@104 $generated@@4 ($generated@@105 $generated@@132 $generated@@133 $generated@@134 $generated@@135) $generated@@136 $generated@@137))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@138 () T@U)
(declare-fun $generated@@139 () T@U)
(declare-fun $generated@@140 () T@U)
(declare-fun $generated@@141 () T@U)
(declare-fun $generated@@142 () Real)
(declare-fun $generated@@143 () Real)
(declare-fun $generated@@144 () Real)
(declare-fun $generated@@145 (T@U) Bool)
(declare-fun $generated@@146 () T@U)
(declare-fun $generated@@147 (T@U) Bool)
(declare-fun $generated@@148 () Real)
(declare-fun $generated@@149 () Real)
(declare-fun $generated@@150 () T@U)
(set-info :boogie-vc-id Impl$$_module.__default.boundedVacuity_split0)
(set-option :timeout 30000)
(set-option :rlimit 2000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 7) (let (($generated@@151  (=> (= $generated@@138 ($generated@@105 $generated@@139 $generated@@140 $generated@@2 false)) (=> (and (= $generated@@141 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) ($generated@@82 $generated@@80 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 0.0)))))) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@141 ($generated@@17 $generated) $generated@@140)) (=> (and (and (= $generated@@142 ($generated@@28 1.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@142) $generated $generated@@140)) (and ($generated@@92 $generated@@141 ($generated@@28 1.0)) ($generated@@92 $generated@@141 ($generated@@28 1.0)))) (and (=> (= (ControlFlow 0 2) (- 0 6)) (=> ($generated@@92 $generated@@141 ($generated@@28 1.0)) (or ($generated@@91 $generated@@141 ($generated@@28 1.0)) (forall (($generated@@152 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@152)))) (<= $generated@@152 ($generated@@28 1.0)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |536|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@152))))
))))) (=> ($generated@@91 $generated@@141 ($generated@@28 1.0)) (=> (and (= $generated@@143 ($generated@@28 0.0)) (= $generated@@144 ($generated@@28 1.0))) (=> (and (and ($generated@@145 $generated@@146) ($generated@@147 $generated@@146)) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) (and ($generated@@92 $generated@@141 $generated@@144) (=> ($generated@@91 $generated@@141 $generated@@144) ($generated@@92 $generated@@141 $generated@@148))))) (=> (and (and (and (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) ($generated@@91 $generated@@141 $generated@@144)) (and ($generated@@92 $generated@@141 $generated@@148) (and ($generated@@91 $generated@@141 $generated@@148) (forall (($generated@@153 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@153)))) (<= $generated@@153 $generated@@148))
 :qid |realcompletenessdfy.199:10|
 :skolemid |585|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@153))))
))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) (and ($generated@@92 $generated@@141 $generated@@144) (=> ($generated@@91 $generated@@141 $generated@@144) (forall (($generated@@154 Real) ) (! ($generated@@92 $generated@@141 $generated@@154)
 :qid |realcompletenessdfy.206:13|
 :skolemid |586|
 :pattern ( ($generated@@91 $generated@@141 $generated@@154))
)))))) (and (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) ($generated@@91 $generated@@141 $generated@@144)) (forall (($generated@@155 Real) ) (!  (=> ($generated@@91 $generated@@141 $generated@@155) (<= $generated@@148 $generated@@155))
 :qid |realcompletenessdfy.206:13|
 :skolemid |587|
 :pattern ( ($generated@@91 $generated@@141 $generated@@155))
))) (= $generated@@140 $generated@@146))) (and (and ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@141 ($generated@@17 $generated) $generated@@146) ($generated@@65 $generated@@6 ($generated@@11 $generated@@148) $generated $generated@@146)) (and ($generated@@92 $generated@@141 $generated@@148) ($generated@@92 $generated@@141 $generated@@148)))) (and (=> (= (ControlFlow 0 2) (- 0 5)) (=> ($generated@@92 $generated@@141 $generated@@148) (or ($generated@@91 $generated@@141 $generated@@148) (forall (($generated@@156 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@156)))) (<= $generated@@156 $generated@@148))
 :qid |realcompletenessdfy.199:10|
 :skolemid |539|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@156))))
))))) (=> (and ($generated@@91 $generated@@141 $generated@@148) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@141 ($generated@@17 $generated) $generated@@146)) (=> (and (and (= $generated@@149 ($generated@@28 0.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@149) $generated $generated@@146)) (and ($generated@@92 $generated@@141 ($generated@@28 0.0)) ($generated@@92 $generated@@141 ($generated@@28 0.0)))) (and (=> (= (ControlFlow 0 2) (- 0 4)) (=> ($generated@@92 $generated@@141 ($generated@@28 0.0)) (or ($generated@@91 $generated@@141 ($generated@@28 0.0)) (forall (($generated@@157 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@157)))) (<= $generated@@157 ($generated@@28 0.0)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |541|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@157))))
))))) (=> ($generated@@91 $generated@@141 ($generated@@28 0.0)) (and (=> (= (ControlFlow 0 2) (- 0 3)) (= $generated@@148 ($generated@@28 0.0))) (=> (= $generated@@148 ($generated@@28 0.0)) (=> (= (ControlFlow 0 2) (- 0 1)) ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 false)))))))))))))))))))))
(let (($generated@@158  (=> (and ($generated@@145 $generated@@140) ($generated@@147 $generated@@140)) (=> (and (and (and ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@150 ($generated@@17 $generated)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@150 ($generated@@17 $generated) $generated@@140)) true) (= (ControlFlow 0 7) 2)) $generated@@151))))
$generated@@158)))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 2) (- 1))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@24 (T@T T@U) T@U)
(declare-fun $generated@@25 () T@T)
(declare-fun $generated@@28 (Real) Real)
(declare-fun $generated@@31 (T@T T@U) T@U)
(declare-fun $generated@@34 (T@U T@U) Bool)
(declare-fun $generated@@35 (T@T T@U T@U) Bool)
(declare-fun $generated@@37 (T@T T@T) T@T)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@T) T@T)
(declare-fun $generated@@41 (T@T) T@T)
(declare-fun $generated@@64 (T@U T@U T@U) Bool)
(declare-fun $generated@@65 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@80 () T@U)
(declare-fun $generated@@82 (T@U Real) Bool)
(declare-fun $generated@@83 (T@U Real) Bool)
(declare-fun $generated@@93 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@94 () T@T)
(declare-fun $generated@@95 () T@T)
(declare-fun $generated@@96 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@97 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@22 T@U) ($generated@@23 T@T) ) (! (= ($generated@@21 $generated@@23 $generated@@22) $generated@@22)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@21 $generated@@23 $generated@@22))
)))
(assert (= ($generated@@3 $generated@@25) 3))
(assert (forall (($generated@@26 T@U) ($generated@@27 T@T) ) (! (= ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)) ($generated@@21 $generated@@25 ($generated@@24 $generated@@27 $generated@@26)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)))
)))
(assert (forall (($generated@@29 Real) ) (! (= ($generated@@28 $generated@@29) $generated@@29)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@28 $generated@@29))
)))
(assert (forall (($generated@@30 Real) ) (! (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))) ($generated@@21 $generated@@25 ($generated@@24 $generated@@6 ($generated@@11 $generated@@30))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@T) ) (! (= ($generated@@31 $generated@@33 ($generated@@24 $generated@@33 $generated@@32)) $generated@@32)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@24 $generated@@33 $generated@@32))
)))
(assert (forall (($generated@@36 T@U) ) (!  (=> ($generated@@34 $generated@@36 $generated) (and (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36)))) $generated@@36) ($generated@@35 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@34 $generated@@36 $generated))
)))
(assert  (and (and (and (and (forall (($generated@@42 T@T) ($generated@@43 T@T) ($generated@@44 T@U) ($generated@@45 T@U) ($generated@@46 T@U) ) (! (= ($generated@@38 $generated@@42 $generated@@43 ($generated@@39 $generated@@42 $generated@@43 $generated@@45 $generated@@46 $generated@@44) $generated@@46) $generated@@44)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@47 T@T) ($generated@@48 T@T) ($generated@@49 T@U) ($generated@@50 T@U) ($generated@@51 T@U) ($generated@@52 T@U) ) (!  (or (= $generated@@51 $generated@@52) (= ($generated@@38 $generated@@47 $generated@@48 ($generated@@39 $generated@@47 $generated@@48 $generated@@50 $generated@@51 $generated@@49) $generated@@52) ($generated@@38 $generated@@47 $generated@@48 $generated@@50 $generated@@52)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@3 ($generated@@37 $generated@@53 $generated@@54)) 4)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@40 ($generated@@37 $generated@@55 $generated@@56)) $generated@@55)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@37 $generated@@55 $generated@@56))
))) (forall (($generated@@57 T@T) ($generated@@58 T@T) ) (! (= ($generated@@41 ($generated@@37 $generated@@57 $generated@@58)) $generated@@58)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@37 $generated@@57 $generated@@58))
))))
(assert (forall (($generated@@59 T@U) ($generated@@60 T@U) ) (!  (=> ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)) (and (= ($generated@@24 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59)) $generated@@59) ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59) ($generated@@17 $generated@@60))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)))
)))
(assert (forall (($generated@@61 T@U) ($generated@@62 T@U) ($generated@@63 T@T) ) (! (= ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62) ($generated@@35 $generated@@63 $generated@@61 $generated@@62))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 T@U) ($generated@@68 T@U) ($generated@@69 T@T) ) (! (= ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68) ($generated@@65 $generated@@69 $generated@@66 $generated@@67 $generated@@68))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68))
)))
(assert (forall (($generated@@70 Real) ) (! ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated))
)))
(assert (forall (($generated@@71 T@U) ($generated@@72 T@U) ) (! (= ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)) (forall (($generated@@73 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73)) ($generated@@34 $generated@@73 $generated@@72))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (! ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74))
)))
(assert (forall (($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ) (! (= ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78) (forall (($generated@@79 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79)) ($generated@@64 $generated@@79 $generated@@77 $generated@@78))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78))
)))
(assert (forall (($generated@@81 T@U) ) (!  (not ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81)))
 :qid |DafnyPreludebpl.837:15|
 :skolemid |155|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81))
)))
(assert (forall (($generated@@84 T@U) ($generated@@85 Real) ) (!  (=> ($generated@@83 $generated@@84 $generated@@85) (= ($generated@@82 $generated@@84 $generated@@85) (forall (($generated@@86 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@84 ($generated@@24 $generated@@6 ($generated@@11 $generated@@86)))) (<= $generated@@86 $generated@@85))
 :qid |realcompletenessdfy.199:10|
 :skolemid |578|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@84 ($generated@@24 $generated@@6 ($generated@@11 $generated@@86))))
))))
 :qid |realcompletenessdfy.198:23|
 :skolemid |579|
 :pattern ( ($generated@@82 $generated@@84 $generated@@85))
)))
(assert (forall (($generated@@87 T@U) ($generated@@88 Real) ) (!  (=> ($generated@@83 $generated@@87 ($generated@@28 $generated@@88)) (= ($generated@@82 $generated@@87 ($generated@@28 $generated@@88)) (forall (($generated@@89 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@87 ($generated@@24 $generated@@6 ($generated@@11 $generated@@89)))) (<= $generated@@89 ($generated@@28 $generated@@88)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |580|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@87 ($generated@@24 $generated@@6 ($generated@@11 $generated@@89))))
))))
 :qid |realcompletenessdfy.198:23|
 :weight 3
 :skolemid |581|
 :pattern ( ($generated@@82 $generated@@87 ($generated@@28 $generated@@88)))
)))
(assert (forall (($generated@@90 T@U) ($generated@@91 Real) ) (!  (=> ($generated@@83 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@28 $generated@@91)) (= ($generated@@82 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@28 $generated@@91)) (forall (($generated@@92 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@24 $generated@@6 ($generated@@11 $generated@@92)))) (<= $generated@@92 ($generated@@28 $generated@@91)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |582|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@90 ($generated@@24 $generated@@6 ($generated@@11 $generated@@92))))
))))
 :qid |realcompletenessdfy.198:23|
 :weight 3
 :skolemid |583|
 :pattern ( ($generated@@82 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@28 $generated@@91)))
)))
(assert  (and (and (and (forall (($generated@@98 T@T) ($generated@@99 T@T) ($generated@@100 T@T) ($generated@@101 T@U) ($generated@@102 T@U) ($generated@@103 T@U) ($generated@@104 T@U) ) (! (= ($generated@@93 $generated@@98 $generated@@99 $generated@@100 ($generated@@97 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@103 $generated@@104 $generated@@101) $generated@@103 $generated@@104) $generated@@101)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@105 T@T) ($generated@@106 T@T) ($generated@@107 T@T) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 T@U) ($generated@@111 T@U) ($generated@@112 T@U) ($generated@@113 T@U) ) (!  (or (= $generated@@110 $generated@@112) (= ($generated@@93 $generated@@105 $generated@@106 $generated@@107 ($generated@@97 $generated@@105 $generated@@106 $generated@@107 $generated@@109 $generated@@110 $generated@@111 $generated@@108) $generated@@112 $generated@@113) ($generated@@93 $generated@@105 $generated@@106 $generated@@107 $generated@@109 $generated@@112 $generated@@113)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@114 T@T) ($generated@@115 T@T) ($generated@@116 T@T) ($generated@@117 T@U) ($generated@@118 T@U) ($generated@@119 T@U) ($generated@@120 T@U) ($generated@@121 T@U) ($generated@@122 T@U) ) (!  (or (= $generated@@120 $generated@@122) (= ($generated@@93 $generated@@114 $generated@@115 $generated@@116 ($generated@@97 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@119 $generated@@120 $generated@@117) $generated@@121 $generated@@122) ($generated@@93 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@121 $generated@@122)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@94) 5)) (= ($generated@@3 $generated@@95) 6)))
(assert (forall (($generated@@123 T@U) ($generated@@124 T@U) ($generated@@125 T@U) ($generated@@126 Bool) ($generated@@127 T@U) ($generated@@128 T@U) ) (! (= ($generated@@8 ($generated@@93 $generated@@94 $generated@@95 $generated@@4 ($generated@@96 $generated@@123 $generated@@124 $generated@@125 $generated@@126) $generated@@127 $generated@@128))  (=> (and (or (not (= $generated@@127 $generated@@123)) (not true)) ($generated@@8 ($generated@@31 $generated@@4 ($generated@@38 $generated@@95 $generated@@25 ($generated@@38 $generated@@94 ($generated@@37 $generated@@95 $generated@@25) $generated@@124 $generated@@127) $generated@@125)))) $generated@@126))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |604|
 :pattern ( ($generated@@93 $generated@@94 $generated@@95 $generated@@4 ($generated@@96 $generated@@123 $generated@@124 $generated@@125 $generated@@126) $generated@@127 $generated@@128))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@129 () T@U)
(declare-fun $generated@@130 () T@U)
(declare-fun $generated@@131 () T@U)
(declare-fun $generated@@132 () T@U)
(declare-fun $generated@@133 () Real)
(declare-fun $generated@@134 () Real)
(declare-fun $generated@@135 (T@U) Bool)
(declare-fun $generated@@136 () T@U)
(declare-fun $generated@@137 (T@U) Bool)
(declare-fun $generated@@138 () Real)
(declare-fun $generated@@139 () Real)
(declare-fun $generated@@140 () T@U)
(set-info :boogie-vc-id Impl$$_module.__default.emptyVacuity_split0)
(set-option :timeout 30000)
(set-option :rlimit 2000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 5) (let (($generated@@141  (=> (and (and (= $generated@@129 ($generated@@96 $generated@@130 $generated@@131 $generated@@2 false)) (= $generated@@132 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@80))) (and (= $generated@@133 ($generated@@28 0.0)) (= $generated@@134 ($generated@@28 0.0)))) (=> (and (and (and ($generated@@135 $generated@@136) ($generated@@137 $generated@@136)) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@133)))) (and ($generated@@83 $generated@@132 $generated@@134) (=> ($generated@@82 $generated@@132 $generated@@134) ($generated@@83 $generated@@132 $generated@@138))))) (and (and (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@133)))) ($generated@@82 $generated@@132 $generated@@134)) (and ($generated@@83 $generated@@132 $generated@@138) (and ($generated@@82 $generated@@132 $generated@@138) (forall (($generated@@142 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@142)))) (<= $generated@@142 $generated@@138))
 :qid |realcompletenessdfy.199:10|
 :skolemid |585|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@142))))
))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@133)))) (and ($generated@@83 $generated@@132 $generated@@134) (=> ($generated@@82 $generated@@132 $generated@@134) (forall (($generated@@143 Real) ) (! ($generated@@83 $generated@@132 $generated@@143)
 :qid |realcompletenessdfy.206:13|
 :skolemid |586|
 :pattern ( ($generated@@82 $generated@@132 $generated@@143))
)))))) (and (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@133)))) ($generated@@82 $generated@@132 $generated@@134)) (forall (($generated@@144 Real) ) (!  (=> ($generated@@82 $generated@@132 $generated@@144) (<= $generated@@138 $generated@@144))
 :qid |realcompletenessdfy.206:13|
 :skolemid |587|
 :pattern ( ($generated@@82 $generated@@132 $generated@@144))
))) (= $generated@@131 $generated@@136)))) (and (=> (= (ControlFlow 0 2) (- 0 4)) (not ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 0.0))))))) (=> (not ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 0.0)))))) (=> ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@132 ($generated@@17 $generated) $generated@@136) (=> (and (and (= $generated@@139 (- $generated@@138 1.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@139) $generated $generated@@136)) (and ($generated@@83 $generated@@132 (- $generated@@138 1.0)) ($generated@@83 $generated@@132 (- $generated@@138 1.0)))) (and (=> (= (ControlFlow 0 2) (- 0 3)) (=> ($generated@@83 $generated@@132 (- $generated@@138 1.0)) (or ($generated@@82 $generated@@132 (- $generated@@138 1.0)) (forall (($generated@@145 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@145)))) (<= $generated@@145 (- $generated@@138 1.0)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |544|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@145))))
))))) (=> (and ($generated@@82 $generated@@132 (- $generated@@138 1.0)) (= (ControlFlow 0 2) (- 0 1))) ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 false)))))))))))))
(let (($generated@@146  (=> (and ($generated@@135 $generated@@131) ($generated@@137 $generated@@131)) (=> (and (and (and ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@140 ($generated@@17 $generated)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@140 ($generated@@17 $generated) $generated@@131)) true) (= (ControlFlow 0 5) 2)) $generated@@141))))
$generated@@146)))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 2) (- 1))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@24 (T@T T@U) T@U)
(declare-fun $generated@@25 () T@T)
(declare-fun $generated@@28 (Real) Real)
(declare-fun $generated@@31 (T@T T@U) T@U)
(declare-fun $generated@@34 (T@U T@U) Bool)
(declare-fun $generated@@35 (T@T T@U T@U) Bool)
(declare-fun $generated@@37 (T@T T@T) T@T)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@T) T@T)
(declare-fun $generated@@41 (T@T) T@T)
(declare-fun $generated@@64 (T@U T@U T@U) Bool)
(declare-fun $generated@@65 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@80 (T@U Real) Bool)
(declare-fun $generated@@81 (T@U Real) Bool)
(declare-fun $generated@@91 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@92 () T@T)
(declare-fun $generated@@93 () T@T)
(declare-fun $generated@@94 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@95 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(declare-fun $generated@@127 (T@U Bool) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@22 T@U) ($generated@@23 T@T) ) (! (= ($generated@@21 $generated@@23 $generated@@22) $generated@@22)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@21 $generated@@23 $generated@@22))
)))
(assert (= ($generated@@3 $generated@@25) 3))
(assert (forall (($generated@@26 T@U) ($generated@@27 T@T) ) (! (= ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)) ($generated@@21 $generated@@25 ($generated@@24 $generated@@27 $generated@@26)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)))
)))
(assert (forall (($generated@@29 Real) ) (! (= ($generated@@28 $generated@@29) $generated@@29)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@28 $generated@@29))
)))
(assert (forall (($generated@@30 Real) ) (! (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))) ($generated@@21 $generated@@25 ($generated@@24 $generated@@6 ($generated@@11 $generated@@30))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@T) ) (! (= ($generated@@31 $generated@@33 ($generated@@24 $generated@@33 $generated@@32)) $generated@@32)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@24 $generated@@33 $generated@@32))
)))
(assert (forall (($generated@@36 T@U) ) (!  (=> ($generated@@34 $generated@@36 $generated) (and (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36)))) $generated@@36) ($generated@@35 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@34 $generated@@36 $generated))
)))
(assert  (and (and (and (and (forall (($generated@@42 T@T) ($generated@@43 T@T) ($generated@@44 T@U) ($generated@@45 T@U) ($generated@@46 T@U) ) (! (= ($generated@@38 $generated@@42 $generated@@43 ($generated@@39 $generated@@42 $generated@@43 $generated@@45 $generated@@46 $generated@@44) $generated@@46) $generated@@44)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@47 T@T) ($generated@@48 T@T) ($generated@@49 T@U) ($generated@@50 T@U) ($generated@@51 T@U) ($generated@@52 T@U) ) (!  (or (= $generated@@51 $generated@@52) (= ($generated@@38 $generated@@47 $generated@@48 ($generated@@39 $generated@@47 $generated@@48 $generated@@50 $generated@@51 $generated@@49) $generated@@52) ($generated@@38 $generated@@47 $generated@@48 $generated@@50 $generated@@52)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@3 ($generated@@37 $generated@@53 $generated@@54)) 4)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@40 ($generated@@37 $generated@@55 $generated@@56)) $generated@@55)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@37 $generated@@55 $generated@@56))
))) (forall (($generated@@57 T@T) ($generated@@58 T@T) ) (! (= ($generated@@41 ($generated@@37 $generated@@57 $generated@@58)) $generated@@58)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@37 $generated@@57 $generated@@58))
))))
(assert (forall (($generated@@59 T@U) ($generated@@60 T@U) ) (!  (=> ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)) (and (= ($generated@@24 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59)) $generated@@59) ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59) ($generated@@17 $generated@@60))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)))
)))
(assert (forall (($generated@@61 T@U) ($generated@@62 T@U) ($generated@@63 T@T) ) (! (= ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62) ($generated@@35 $generated@@63 $generated@@61 $generated@@62))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 T@U) ($generated@@68 T@U) ($generated@@69 T@T) ) (! (= ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68) ($generated@@65 $generated@@69 $generated@@66 $generated@@67 $generated@@68))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68))
)))
(assert (forall (($generated@@70 Real) ) (! ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated))
)))
(assert (forall (($generated@@71 T@U) ($generated@@72 T@U) ) (! (= ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)) (forall (($generated@@73 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73)) ($generated@@34 $generated@@73 $generated@@72))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (! ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74))
)))
(assert (forall (($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ) (! (= ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78) (forall (($generated@@79 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79)) ($generated@@64 $generated@@79 $generated@@77 $generated@@78))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78))
)))
(assert (forall (($generated@@82 T@U) ($generated@@83 Real) ) (!  (=> ($generated@@81 $generated@@82 $generated@@83) (= ($generated@@80 $generated@@82 $generated@@83) (forall (($generated@@84 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@82 ($generated@@24 $generated@@6 ($generated@@11 $generated@@84)))) (<= $generated@@84 $generated@@83))
 :qid |realcompletenessdfy.199:10|
 :skolemid |578|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@82 ($generated@@24 $generated@@6 ($generated@@11 $generated@@84))))
))))
 :qid |realcompletenessdfy.198:23|
 :skolemid |579|
 :pattern ( ($generated@@80 $generated@@82 $generated@@83))
)))
(assert (forall (($generated@@85 T@U) ($generated@@86 Real) ) (!  (=> ($generated@@81 $generated@@85 ($generated@@28 $generated@@86)) (= ($generated@@80 $generated@@85 ($generated@@28 $generated@@86)) (forall (($generated@@87 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@85 ($generated@@24 $generated@@6 ($generated@@11 $generated@@87)))) (<= $generated@@87 ($generated@@28 $generated@@86)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |580|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@85 ($generated@@24 $generated@@6 ($generated@@11 $generated@@87))))
))))
 :qid |realcompletenessdfy.198:23|
 :weight 3
 :skolemid |581|
 :pattern ( ($generated@@80 $generated@@85 ($generated@@28 $generated@@86)))
)))
(assert (forall (($generated@@88 T@U) ($generated@@89 Real) ) (!  (=> ($generated@@81 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@28 $generated@@89)) (= ($generated@@80 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@28 $generated@@89)) (forall (($generated@@90 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@24 $generated@@6 ($generated@@11 $generated@@90)))) (<= $generated@@90 ($generated@@28 $generated@@89)))
 :qid |realcompletenessdfy.199:10|
 :skolemid |582|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@88 ($generated@@24 $generated@@6 ($generated@@11 $generated@@90))))
))))
 :qid |realcompletenessdfy.198:23|
 :weight 3
 :skolemid |583|
 :pattern ( ($generated@@80 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@28 $generated@@89)))
)))
(assert  (and (and (and (forall (($generated@@96 T@T) ($generated@@97 T@T) ($generated@@98 T@T) ($generated@@99 T@U) ($generated@@100 T@U) ($generated@@101 T@U) ($generated@@102 T@U) ) (! (= ($generated@@91 $generated@@96 $generated@@97 $generated@@98 ($generated@@95 $generated@@96 $generated@@97 $generated@@98 $generated@@100 $generated@@101 $generated@@102 $generated@@99) $generated@@101 $generated@@102) $generated@@99)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@103 T@T) ($generated@@104 T@T) ($generated@@105 T@T) ($generated@@106 T@U) ($generated@@107 T@U) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 T@U) ($generated@@111 T@U) ) (!  (or (= $generated@@108 $generated@@110) (= ($generated@@91 $generated@@103 $generated@@104 $generated@@105 ($generated@@95 $generated@@103 $generated@@104 $generated@@105 $generated@@107 $generated@@108 $generated@@109 $generated@@106) $generated@@110 $generated@@111) ($generated@@91 $generated@@103 $generated@@104 $generated@@105 $generated@@107 $generated@@110 $generated@@111)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@112 T@T) ($generated@@113 T@T) ($generated@@114 T@T) ($generated@@115 T@U) ($generated@@116 T@U) ($generated@@117 T@U) ($generated@@118 T@U) ($generated@@119 T@U) ($generated@@120 T@U) ) (!  (or (= $generated@@118 $generated@@120) (= ($generated@@91 $generated@@112 $generated@@113 $generated@@114 ($generated@@95 $generated@@112 $generated@@113 $generated@@114 $generated@@116 $generated@@117 $generated@@118 $generated@@115) $generated@@119 $generated@@120) ($generated@@91 $generated@@112 $generated@@113 $generated@@114 $generated@@116 $generated@@119 $generated@@120)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@92) 5)) (= ($generated@@3 $generated@@93) 6)))
(assert (forall (($generated@@121 T@U) ($generated@@122 T@U) ($generated@@123 T@U) ($generated@@124 Bool) ($generated@@125 T@U) ($generated@@126 T@U) ) (! (= ($generated@@8 ($generated@@91 $generated@@92 $generated@@93 $generated@@4 ($generated@@94 $generated@@121 $generated@@122 $generated@@123 $generated@@124) $generated@@125 $generated@@126))  (=> (and (or (not (= $generated@@125 $generated@@121)) (not true)) ($generated@@8 ($generated@@31 $generated@@4 ($generated@@38 $generated@@93 $generated@@25 ($generated@@38 $generated@@92 ($generated@@37 $generated@@93 $generated@@25) $generated@@122 $generated@@125) $generated@@123)))) $generated@@124))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |604|
 :pattern ( ($generated@@91 $generated@@92 $generated@@93 $generated@@4 ($generated@@94 $generated@@121 $generated@@122 $generated@@123 $generated@@124) $generated@@125 $generated@@126))
)))
(assert (forall (($generated@@128 T@U) ($generated@@129 Bool) ($generated@@130 T@U) ) (! (= ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@127 $generated@@128 $generated@@129) $generated@@130))  (and ($generated@@34 $generated@@130 $generated@@128) $generated@@129))
 :qid |DafnyPreludebpl.33:1|
 :skolemid |605|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 ($generated@@127 $generated@@128 $generated@@129) $generated@@130))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@131 () T@U)
(declare-fun $generated@@132 () Real)
(declare-fun $generated@@133 () Real)
(declare-fun $generated@@134 (T@U) Bool)
(declare-fun $generated@@135 () T@U)
(declare-fun $generated@@136 (T@U) Bool)
(declare-fun $generated@@137 () Real)
(declare-fun $generated@@138 () T@U)
(declare-fun $generated@@139 () Real)
(declare-fun $generated@@140 () T@U)
(declare-fun $generated@@141 () T@U)
(declare-fun $generated@@142 () T@U)
(set-info :boogie-vc-id Impl$$_module.__default.unboundedVacuity_split0)
(set-option :timeout 30000)
(set-option :rlimit 2000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 12) (let (($generated@@143  (=> (= $generated@@131 ($generated@@127 $generated ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 true))))) (=> (and (= $generated@@132 ($generated@@28 0.0)) (= $generated@@133 ($generated@@28 0.0))) (=> (and (and (and ($generated@@134 $generated@@135) ($generated@@136 $generated@@135)) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@132)))) (and ($generated@@81 $generated@@131 $generated@@133) (=> ($generated@@80 $generated@@131 $generated@@133) ($generated@@81 $generated@@131 $generated@@137))))) (and (and (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@132)))) ($generated@@80 $generated@@131 $generated@@133)) (and ($generated@@81 $generated@@131 $generated@@137) (and ($generated@@80 $generated@@131 $generated@@137) (forall (($generated@@144 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@144)))) (<= $generated@@144 $generated@@137))
 :qid |realcompletenessdfy.199:10|
 :skolemid |585|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@144))))
))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@132)))) (and ($generated@@81 $generated@@131 $generated@@133) (=> ($generated@@80 $generated@@131 $generated@@133) (forall (($generated@@145 Real) ) (! ($generated@@81 $generated@@131 $generated@@145)
 :qid |realcompletenessdfy.206:13|
 :skolemid |586|
 :pattern ( ($generated@@80 $generated@@131 $generated@@145))
)))))) (and (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@132)))) ($generated@@80 $generated@@131 $generated@@133)) (forall (($generated@@146 Real) ) (!  (=> ($generated@@80 $generated@@131 $generated@@146) (<= $generated@@137 $generated@@146))
 :qid |realcompletenessdfy.206:13|
 :skolemid |587|
 :pattern ( ($generated@@80 $generated@@131 $generated@@146))
))) (= $generated@@138 $generated@@135)))) (and (=> (= (ControlFlow 0 3) (- 0 7)) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 0.0)))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 0.0))))) (and (=> (= (ControlFlow 0 3) (- 0 6)) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 1.0)))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 1.0))))) (and (=> (= (ControlFlow 0 3) (- 0 5)) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 (+ $generated@@137 1.0)))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 (+ $generated@@137 1.0))))) (=> ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@131 ($generated@@17 $generated) $generated@@135) (=> (and (and (= $generated@@139 ($generated@@28 0.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@139) $generated $generated@@135)) (and ($generated@@81 $generated@@131 ($generated@@28 0.0)) ($generated@@81 $generated@@131 ($generated@@28 0.0)))) (and (=> (= (ControlFlow 0 3) (- 0 4)) (not ($generated@@80 $generated@@131 ($generated@@28 0.0)))) (=> (not ($generated@@80 $generated@@131 ($generated@@28 0.0))) (=> (= (ControlFlow 0 3) (- 0 2)) ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 false)))))))))))))))))))
(let (($generated@@147  (=> (and (not ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 true)))) (= (ControlFlow 0 9) 3)) $generated@@143)))
(let (($generated@@148  (=> (and ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 true))) (= (ControlFlow 0 8) 3)) $generated@@143)))
(let (($generated@@149  (and (=> (= (ControlFlow 0 10) 8) $generated@@148) (=> (= (ControlFlow 0 10) 9) $generated@@147))))
(let (($generated@@150 true))
(let (($generated@@151  (=> (= $generated@@140 ($generated@@94 $generated@@141 $generated@@138 $generated@@2 false)) (and (=> (= (ControlFlow 0 11) 10) $generated@@149) (=> (= (ControlFlow 0 11) 1) $generated@@150)))))
(let (($generated@@152  (=> (and ($generated@@134 $generated@@138) ($generated@@136 $generated@@138)) (=> (and (and (and ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@142 ($generated@@17 $generated)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@142 ($generated@@17 $generated) $generated@@138)) true) (= (ControlFlow 0 12) 11)) $generated@@151))))
$generated@@152))))))))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 3) (- 2))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
