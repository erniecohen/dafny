(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@22 (T@T T@U) T@U)
(declare-fun $generated@@25 (T@U T@U) Bool)
(declare-fun $generated@@26 (T@T T@U T@U) Bool)
(declare-fun $generated@@28 (T@T T@T) T@T)
(declare-fun $generated@@29 () T@T)
(declare-fun $generated@@30 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@31 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@32 (T@T) T@T)
(declare-fun $generated@@33 (T@T) T@T)
(declare-fun $generated@@56 (T@U T@U T@U) Bool)
(declare-fun $generated@@57 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@72 (T@U Real) Bool)
(declare-fun $generated@@73 (T@U Real) Bool)
(declare-fun $generated@@77 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@78 () T@T)
(declare-fun $generated@@79 () T@T)
(declare-fun $generated@@80 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@81 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@23 T@U) ($generated@@24 T@T) ) (! (= ($generated@@22 $generated@@24 ($generated@@21 $generated@@24 $generated@@23)) $generated@@23)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@21 $generated@@24 $generated@@23))
)))
(assert (forall (($generated@@27 T@U) ) (!  (=> ($generated@@25 $generated@@27 $generated) (and (= ($generated@@21 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27)))) $generated@@27) ($generated@@26 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@25 $generated@@27 $generated))
)))
(assert  (and (and (and (and (and (forall (($generated@@34 T@T) ($generated@@35 T@T) ($generated@@36 T@U) ($generated@@37 T@U) ($generated@@38 T@U) ) (! (= ($generated@@30 $generated@@34 $generated@@35 ($generated@@31 $generated@@34 $generated@@35 $generated@@37 $generated@@38 $generated@@36) $generated@@38) $generated@@36)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@39 T@T) ($generated@@40 T@T) ($generated@@41 T@U) ($generated@@42 T@U) ($generated@@43 T@U) ($generated@@44 T@U) ) (!  (or (= $generated@@43 $generated@@44) (= ($generated@@30 $generated@@39 $generated@@40 ($generated@@31 $generated@@39 $generated@@40 $generated@@42 $generated@@43 $generated@@41) $generated@@44) ($generated@@30 $generated@@39 $generated@@40 $generated@@42 $generated@@44)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@45 T@T) ($generated@@46 T@T) ) (! (= ($generated@@3 ($generated@@28 $generated@@45 $generated@@46)) 3)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@47 T@T) ($generated@@48 T@T) ) (! (= ($generated@@32 ($generated@@28 $generated@@47 $generated@@48)) $generated@@47)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@28 $generated@@47 $generated@@48))
))) (forall (($generated@@49 T@T) ($generated@@50 T@T) ) (! (= ($generated@@33 ($generated@@28 $generated@@49 $generated@@50)) $generated@@50)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@28 $generated@@49 $generated@@50))
))) (= ($generated@@3 $generated@@29) 4)))
(assert (forall (($generated@@51 T@U) ($generated@@52 T@U) ) (!  (=> ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)) (and (= ($generated@@21 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51)) $generated@@51) ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51) ($generated@@17 $generated@@52))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)))
)))
(assert (forall (($generated@@53 T@U) ($generated@@54 T@U) ($generated@@55 T@T) ) (! (= ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54) ($generated@@26 $generated@@55 $generated@@53 $generated@@54))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54))
)))
(assert (forall (($generated@@58 T@U) ($generated@@59 T@U) ($generated@@60 T@U) ($generated@@61 T@T) ) (! (= ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60) ($generated@@57 $generated@@61 $generated@@58 $generated@@59 $generated@@60))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60))
)))
(assert (forall (($generated@@62 Real) ) (! ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated))
)))
(assert (forall (($generated@@63 T@U) ($generated@@64 T@U) ) (! (= ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)) (forall (($generated@@65 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65)) ($generated@@25 $generated@@65 $generated@@64))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 Real) ) (! ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66))
)))
(assert (forall (($generated@@68 T@U) ($generated@@69 T@U) ($generated@@70 T@U) ) (! (= ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70) (forall (($generated@@71 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71)) ($generated@@56 $generated@@71 $generated@@69 $generated@@70))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (!  (=> ($generated@@73 $generated@@74 $generated@@75) (= ($generated@@72 $generated@@74 $generated@@75) (forall (($generated@@76 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76)))) (<= $generated@@76 $generated@@75))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@72 $generated@@74 $generated@@75))
)))
(assert  (and (and (and (forall (($generated@@82 T@T) ($generated@@83 T@T) ($generated@@84 T@T) ($generated@@85 T@U) ($generated@@86 T@U) ($generated@@87 T@U) ($generated@@88 T@U) ) (! (= ($generated@@77 $generated@@82 $generated@@83 $generated@@84 ($generated@@81 $generated@@82 $generated@@83 $generated@@84 $generated@@86 $generated@@87 $generated@@88 $generated@@85) $generated@@87 $generated@@88) $generated@@85)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@89 T@T) ($generated@@90 T@T) ($generated@@91 T@T) ($generated@@92 T@U) ($generated@@93 T@U) ($generated@@94 T@U) ($generated@@95 T@U) ($generated@@96 T@U) ($generated@@97 T@U) ) (!  (or (= $generated@@94 $generated@@96) (= ($generated@@77 $generated@@89 $generated@@90 $generated@@91 ($generated@@81 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@94 $generated@@95 $generated@@92) $generated@@96 $generated@@97) ($generated@@77 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@96 $generated@@97)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@98 T@T) ($generated@@99 T@T) ($generated@@100 T@T) ($generated@@101 T@U) ($generated@@102 T@U) ($generated@@103 T@U) ($generated@@104 T@U) ($generated@@105 T@U) ($generated@@106 T@U) ) (!  (or (= $generated@@104 $generated@@106) (= ($generated@@77 $generated@@98 $generated@@99 $generated@@100 ($generated@@81 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@103 $generated@@104 $generated@@101) $generated@@105 $generated@@106) ($generated@@77 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@105 $generated@@106)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@78) 5)) (= ($generated@@3 $generated@@79) 6)))
(assert (forall (($generated@@107 T@U) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 Bool) ($generated@@111 T@U) ($generated@@112 T@U) ) (! (= ($generated@@8 ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))  (=> (and (or (not (= $generated@@111 $generated@@107)) (not true)) ($generated@@8 ($generated@@22 $generated@@4 ($generated@@30 $generated@@79 $generated@@29 ($generated@@30 $generated@@78 ($generated@@28 $generated@@79 $generated@@29) $generated@@108 $generated@@111) $generated@@109)))) $generated@@110))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@113 () T@U)
(declare-fun $generated@@114 () T@U)
(declare-fun $generated@@115 () T@U)
(declare-fun $generated@@116 (T@U) Bool)
(declare-fun $generated@@117 () T@U)
(declare-fun $generated@@118 (T@U) Bool)
(declare-fun $generated@@119 () T@U)
(declare-fun $generated@@120 () Real)
(declare-fun $generated@@121 () Real)
(declare-fun $generated@@122 () Real)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.lub_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 5) (let (($generated@@123  (=> (= $generated@@113 ($generated@@80 $generated@@114 $generated@@115 $generated@@2 false)) (=> (and (and (and ($generated@@116 $generated@@117) ($generated@@118 $generated@@117)) (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@120)))) (and ($generated@@73 $generated@@119 $generated@@121) (=> ($generated@@72 $generated@@119 $generated@@121) ($generated@@73 $generated@@119 $generated@@122))))) (and (and (=> (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@120)))) ($generated@@72 $generated@@119 $generated@@121)) (and ($generated@@73 $generated@@119 $generated@@122) (and ($generated@@72 $generated@@119 $generated@@122) (forall (($generated@@124 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@124)))) (<= $generated@@124 $generated@@122))
 :qid |sourcekerneldfy.4:12|
 :skolemid |550|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@124))))
))))) (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@120)))) (and ($generated@@73 $generated@@119 $generated@@121) (=> ($generated@@72 $generated@@119 $generated@@121) (forall (($generated@@125 Real) ) (! ($generated@@73 $generated@@119 $generated@@125)
 :qid |sourcekerneldfy.11:14|
 :skolemid |551|
 :pattern ( ($generated@@72 $generated@@119 $generated@@125))
)))))) (and (=> (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@120)))) ($generated@@72 $generated@@119 $generated@@121)) (forall (($generated@@126 Real) ) (!  (=> ($generated@@72 $generated@@119 $generated@@126) (<= $generated@@122 $generated@@126))
 :qid |sourcekerneldfy.11:14|
 :skolemid |552|
 :pattern ( ($generated@@72 $generated@@119 $generated@@126))
))) (= $generated@@115 $generated@@117)))) (and (=> (= (ControlFlow 0 2) (- 0 4)) true) (=> ($generated@@73 $generated@@119 $generated@@122) (and (=> (= (ControlFlow 0 2) (- 0 3)) (=> ($generated@@73 $generated@@119 $generated@@122) (or ($generated@@72 $generated@@119 $generated@@122) (forall (($generated@@127 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@127)))) (<= $generated@@127 $generated@@122))
 :qid |sourcekerneldfy.4:12|
 :skolemid |562|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@127))))
))))) (=> (=> ($generated@@73 $generated@@119 $generated@@122) (or ($generated@@72 $generated@@119 $generated@@122) (forall (($generated@@128 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@128)))) (<= $generated@@128 $generated@@122))
 :qid |sourcekerneldfy.4:12|
 :skolemid |562|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@128))))
)))) (=> (and (forall (($generated@@129 Real) ) (! ($generated@@73 $generated@@119 $generated@@129)
 :qid |sourcekerneldfy.17:20|
 :skolemid |564|
 :pattern ( ($generated@@72 $generated@@119 $generated@@129))
)) (= (ControlFlow 0 2) (- 0 1))) (forall (($generated@@130 Real) ) (!  (=> ($generated@@72 $generated@@119 $generated@@130) (<= $generated@@122 $generated@@130))
 :qid |sourcekerneldfy.17:20|
 :skolemid |565|
 :pattern ( ($generated@@72 $generated@@119 $generated@@130))
)))))))))))
(let (($generated@@131  (=> (and ($generated@@116 $generated@@115) ($generated@@118 $generated@@115)) (=> (and (and (and ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@119 ($generated@@17 $generated)) ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@119 ($generated@@17 $generated) $generated@@115)) (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@120)))) ($generated@@73 $generated@@119 $generated@@121))) (and (and ($generated@@73 $generated@@119 $generated@@121) (and ($generated@@72 $generated@@119 $generated@@121) (forall (($generated@@132 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@132)))) (<= $generated@@132 $generated@@121))
 :qid |sourcekerneldfy.4:12|
 :skolemid |561|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@132))))
)))) (= (ControlFlow 0 5) 2))) $generated@@123))))
$generated@@131)))
))
(check-sat)
(get-info :rlimit)
(pop 1)
; Valid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@22 (T@T T@U) T@U)
(declare-fun $generated@@25 (T@U T@U) Bool)
(declare-fun $generated@@26 (T@T T@U T@U) Bool)
(declare-fun $generated@@28 (T@T T@T) T@T)
(declare-fun $generated@@29 () T@T)
(declare-fun $generated@@30 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@31 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@32 (T@T) T@T)
(declare-fun $generated@@33 (T@T) T@T)
(declare-fun $generated@@56 (T@U T@U T@U) Bool)
(declare-fun $generated@@57 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@72 (T@U Real) Bool)
(declare-fun $generated@@73 (T@U Real) Bool)
(declare-fun $generated@@77 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@78 () T@T)
(declare-fun $generated@@79 () T@T)
(declare-fun $generated@@80 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@81 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@23 T@U) ($generated@@24 T@T) ) (! (= ($generated@@22 $generated@@24 ($generated@@21 $generated@@24 $generated@@23)) $generated@@23)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@21 $generated@@24 $generated@@23))
)))
(assert (forall (($generated@@27 T@U) ) (!  (=> ($generated@@25 $generated@@27 $generated) (and (= ($generated@@21 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27)))) $generated@@27) ($generated@@26 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@25 $generated@@27 $generated))
)))
(assert  (and (and (and (and (and (forall (($generated@@34 T@T) ($generated@@35 T@T) ($generated@@36 T@U) ($generated@@37 T@U) ($generated@@38 T@U) ) (! (= ($generated@@30 $generated@@34 $generated@@35 ($generated@@31 $generated@@34 $generated@@35 $generated@@37 $generated@@38 $generated@@36) $generated@@38) $generated@@36)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@39 T@T) ($generated@@40 T@T) ($generated@@41 T@U) ($generated@@42 T@U) ($generated@@43 T@U) ($generated@@44 T@U) ) (!  (or (= $generated@@43 $generated@@44) (= ($generated@@30 $generated@@39 $generated@@40 ($generated@@31 $generated@@39 $generated@@40 $generated@@42 $generated@@43 $generated@@41) $generated@@44) ($generated@@30 $generated@@39 $generated@@40 $generated@@42 $generated@@44)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@45 T@T) ($generated@@46 T@T) ) (! (= ($generated@@3 ($generated@@28 $generated@@45 $generated@@46)) 3)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@47 T@T) ($generated@@48 T@T) ) (! (= ($generated@@32 ($generated@@28 $generated@@47 $generated@@48)) $generated@@47)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@28 $generated@@47 $generated@@48))
))) (forall (($generated@@49 T@T) ($generated@@50 T@T) ) (! (= ($generated@@33 ($generated@@28 $generated@@49 $generated@@50)) $generated@@50)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@28 $generated@@49 $generated@@50))
))) (= ($generated@@3 $generated@@29) 4)))
(assert (forall (($generated@@51 T@U) ($generated@@52 T@U) ) (!  (=> ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)) (and (= ($generated@@21 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51)) $generated@@51) ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51) ($generated@@17 $generated@@52))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)))
)))
(assert (forall (($generated@@53 T@U) ($generated@@54 T@U) ($generated@@55 T@T) ) (! (= ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54) ($generated@@26 $generated@@55 $generated@@53 $generated@@54))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54))
)))
(assert (forall (($generated@@58 T@U) ($generated@@59 T@U) ($generated@@60 T@U) ($generated@@61 T@T) ) (! (= ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60) ($generated@@57 $generated@@61 $generated@@58 $generated@@59 $generated@@60))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60))
)))
(assert (forall (($generated@@62 Real) ) (! ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated))
)))
(assert (forall (($generated@@63 T@U) ($generated@@64 T@U) ) (! (= ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)) (forall (($generated@@65 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65)) ($generated@@25 $generated@@65 $generated@@64))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 Real) ) (! ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66))
)))
(assert (forall (($generated@@68 T@U) ($generated@@69 T@U) ($generated@@70 T@U) ) (! (= ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70) (forall (($generated@@71 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71)) ($generated@@56 $generated@@71 $generated@@69 $generated@@70))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (!  (=> ($generated@@73 $generated@@74 $generated@@75) (= ($generated@@72 $generated@@74 $generated@@75) (forall (($generated@@76 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76)))) (<= $generated@@76 $generated@@75))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@72 $generated@@74 $generated@@75))
)))
(assert  (and (and (and (forall (($generated@@82 T@T) ($generated@@83 T@T) ($generated@@84 T@T) ($generated@@85 T@U) ($generated@@86 T@U) ($generated@@87 T@U) ($generated@@88 T@U) ) (! (= ($generated@@77 $generated@@82 $generated@@83 $generated@@84 ($generated@@81 $generated@@82 $generated@@83 $generated@@84 $generated@@86 $generated@@87 $generated@@88 $generated@@85) $generated@@87 $generated@@88) $generated@@85)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@89 T@T) ($generated@@90 T@T) ($generated@@91 T@T) ($generated@@92 T@U) ($generated@@93 T@U) ($generated@@94 T@U) ($generated@@95 T@U) ($generated@@96 T@U) ($generated@@97 T@U) ) (!  (or (= $generated@@94 $generated@@96) (= ($generated@@77 $generated@@89 $generated@@90 $generated@@91 ($generated@@81 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@94 $generated@@95 $generated@@92) $generated@@96 $generated@@97) ($generated@@77 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@96 $generated@@97)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@98 T@T) ($generated@@99 T@T) ($generated@@100 T@T) ($generated@@101 T@U) ($generated@@102 T@U) ($generated@@103 T@U) ($generated@@104 T@U) ($generated@@105 T@U) ($generated@@106 T@U) ) (!  (or (= $generated@@104 $generated@@106) (= ($generated@@77 $generated@@98 $generated@@99 $generated@@100 ($generated@@81 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@103 $generated@@104 $generated@@101) $generated@@105 $generated@@106) ($generated@@77 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@105 $generated@@106)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@78) 5)) (= ($generated@@3 $generated@@79) 6)))
(assert (forall (($generated@@107 T@U) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 Bool) ($generated@@111 T@U) ($generated@@112 T@U) ) (! (= ($generated@@8 ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))  (=> (and (or (not (= $generated@@111 $generated@@107)) (not true)) ($generated@@8 ($generated@@22 $generated@@4 ($generated@@30 $generated@@79 $generated@@29 ($generated@@30 $generated@@78 ($generated@@28 $generated@@79 $generated@@29) $generated@@108 $generated@@111) $generated@@109)))) $generated@@110))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@113 () Real)
(declare-fun $generated@@114 () Real)
(declare-fun $generated@@115 () Real)
(declare-fun $generated@@116 () T@U)
(declare-fun $generated@@117 () T@U)
(declare-fun $generated@@118 () T@U)
(declare-fun $generated@@119 () T@U)
(declare-fun $generated@@120 (T@U) Bool)
(declare-fun $generated@@121 () T@U)
(declare-fun $generated@@122 (T@U) Bool)
(declare-fun $generated@@123 () Real)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.upperUse_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 10) (let (($generated@@124  (and (=> (= (ControlFlow 0 2) (- 0 3)) (<= $generated@@113 $generated@@114)) (=> (= (ControlFlow 0 2) (- 0 1)) (<= $generated@@114 $generated@@115)))))
(let (($generated@@125  (=> (and (< $generated@@114 $generated@@113) (= (ControlFlow 0 5) 2)) $generated@@124)))
(let (($generated@@126  (=> (and (<= $generated@@113 $generated@@114) (= (ControlFlow 0 4) 2)) $generated@@124)))
(let (($generated@@127  (=> (= $generated@@116 ($generated@@80 $generated@@117 $generated@@118 $generated@@2 false)) (and (=> (= (ControlFlow 0 6) (- 0 9)) ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@113))))) (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@113)))) (=> ($generated@@73 $generated@@119 $generated@@115) (and (=> (= (ControlFlow 0 6) (- 0 8)) (=> ($generated@@73 $generated@@119 $generated@@115) (or ($generated@@72 $generated@@119 $generated@@115) (forall (($generated@@128 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@128)))) (<= $generated@@128 $generated@@115))
 :qid |sourcekerneldfy.4:12|
 :skolemid |554|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@128))))
))))) (=> (=> ($generated@@73 $generated@@119 $generated@@115) (or ($generated@@72 $generated@@119 $generated@@115) (forall (($generated@@129 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@129)))) (<= $generated@@129 $generated@@115))
 :qid |sourcekerneldfy.4:12|
 :skolemid |554|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@129))))
)))) (=> (and (and ($generated@@120 $generated@@121) ($generated@@122 $generated@@121)) ($generated@@73 $generated@@119 $generated@@114)) (=> (and (and (and ($generated@@73 $generated@@119 $generated@@114) (and ($generated@@72 $generated@@119 $generated@@114) (forall (($generated@@130 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@130)))) (<= $generated@@130 $generated@@114))
 :qid |sourcekerneldfy.4:12|
 :skolemid |557|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@130))))
)))) (forall (($generated@@131 Real) ) (! ($generated@@73 $generated@@119 $generated@@131)
 :qid |sourcekerneldfy.17:20|
 :skolemid |558|
 :pattern ( ($generated@@72 $generated@@119 $generated@@131))
))) (and (forall (($generated@@132 Real) ) (!  (=> ($generated@@72 $generated@@119 $generated@@132) (<= $generated@@114 $generated@@132))
 :qid |sourcekerneldfy.17:20|
 :skolemid |559|
 :pattern ( ($generated@@72 $generated@@119 $generated@@132))
)) (= $generated@@118 $generated@@121))) (and (=> (= (ControlFlow 0 6) (- 0 7)) (<= $generated@@123 $generated@@114)) (=> (<= $generated@@123 $generated@@114) (and (=> (= (ControlFlow 0 6) 4) $generated@@126) (=> (= (ControlFlow 0 6) 5) $generated@@125))))))))))))))
(let (($generated@@133  (=> (and ($generated@@120 $generated@@118) ($generated@@122 $generated@@118)) (=> (and (and (and ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@119 ($generated@@17 $generated)) ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@119 ($generated@@17 $generated) $generated@@118)) (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@113)))) ($generated@@73 $generated@@119 $generated@@115))) (and (and ($generated@@73 $generated@@119 $generated@@115) (and ($generated@@72 $generated@@119 $generated@@115) (forall (($generated@@134 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@134)))) (<= $generated@@134 $generated@@115))
 :qid |sourcekerneldfy.4:12|
 :skolemid |570|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@134))))
)))) (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@119 ($generated@@21 $generated@@6 ($generated@@11 $generated@@123)))) (= (ControlFlow 0 10) 6)))) $generated@@127))))
$generated@@133))))))
))
(check-sat)
(get-info :rlimit)
(pop 1)
; Valid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@22 (T@T T@U) T@U)
(declare-fun $generated@@25 (T@U T@U) Bool)
(declare-fun $generated@@26 (T@T T@U T@U) Bool)
(declare-fun $generated@@28 (T@T T@T) T@T)
(declare-fun $generated@@29 () T@T)
(declare-fun $generated@@30 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@31 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@32 (T@T) T@T)
(declare-fun $generated@@33 (T@T) T@T)
(declare-fun $generated@@56 (T@U T@U T@U) Bool)
(declare-fun $generated@@57 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@72 (T@U Real) Bool)
(declare-fun $generated@@73 (T@U Real) Bool)
(declare-fun $generated@@77 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@78 () T@T)
(declare-fun $generated@@79 () T@T)
(declare-fun $generated@@80 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@81 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@23 T@U) ($generated@@24 T@T) ) (! (= ($generated@@22 $generated@@24 ($generated@@21 $generated@@24 $generated@@23)) $generated@@23)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@21 $generated@@24 $generated@@23))
)))
(assert (forall (($generated@@27 T@U) ) (!  (=> ($generated@@25 $generated@@27 $generated) (and (= ($generated@@21 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27)))) $generated@@27) ($generated@@26 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@25 $generated@@27 $generated))
)))
(assert  (and (and (and (and (and (forall (($generated@@34 T@T) ($generated@@35 T@T) ($generated@@36 T@U) ($generated@@37 T@U) ($generated@@38 T@U) ) (! (= ($generated@@30 $generated@@34 $generated@@35 ($generated@@31 $generated@@34 $generated@@35 $generated@@37 $generated@@38 $generated@@36) $generated@@38) $generated@@36)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@39 T@T) ($generated@@40 T@T) ($generated@@41 T@U) ($generated@@42 T@U) ($generated@@43 T@U) ($generated@@44 T@U) ) (!  (or (= $generated@@43 $generated@@44) (= ($generated@@30 $generated@@39 $generated@@40 ($generated@@31 $generated@@39 $generated@@40 $generated@@42 $generated@@43 $generated@@41) $generated@@44) ($generated@@30 $generated@@39 $generated@@40 $generated@@42 $generated@@44)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@45 T@T) ($generated@@46 T@T) ) (! (= ($generated@@3 ($generated@@28 $generated@@45 $generated@@46)) 3)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@47 T@T) ($generated@@48 T@T) ) (! (= ($generated@@32 ($generated@@28 $generated@@47 $generated@@48)) $generated@@47)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@28 $generated@@47 $generated@@48))
))) (forall (($generated@@49 T@T) ($generated@@50 T@T) ) (! (= ($generated@@33 ($generated@@28 $generated@@49 $generated@@50)) $generated@@50)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@28 $generated@@49 $generated@@50))
))) (= ($generated@@3 $generated@@29) 4)))
(assert (forall (($generated@@51 T@U) ($generated@@52 T@U) ) (!  (=> ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)) (and (= ($generated@@21 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51)) $generated@@51) ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51) ($generated@@17 $generated@@52))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)))
)))
(assert (forall (($generated@@53 T@U) ($generated@@54 T@U) ($generated@@55 T@T) ) (! (= ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54) ($generated@@26 $generated@@55 $generated@@53 $generated@@54))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54))
)))
(assert (forall (($generated@@58 T@U) ($generated@@59 T@U) ($generated@@60 T@U) ($generated@@61 T@T) ) (! (= ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60) ($generated@@57 $generated@@61 $generated@@58 $generated@@59 $generated@@60))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60))
)))
(assert (forall (($generated@@62 Real) ) (! ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated))
)))
(assert (forall (($generated@@63 T@U) ($generated@@64 T@U) ) (! (= ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)) (forall (($generated@@65 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65)) ($generated@@25 $generated@@65 $generated@@64))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 Real) ) (! ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66))
)))
(assert (forall (($generated@@68 T@U) ($generated@@69 T@U) ($generated@@70 T@U) ) (! (= ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70) (forall (($generated@@71 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71)) ($generated@@56 $generated@@71 $generated@@69 $generated@@70))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (!  (=> ($generated@@73 $generated@@74 $generated@@75) (= ($generated@@72 $generated@@74 $generated@@75) (forall (($generated@@76 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76)))) (<= $generated@@76 $generated@@75))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@72 $generated@@74 $generated@@75))
)))
(assert  (and (and (and (forall (($generated@@82 T@T) ($generated@@83 T@T) ($generated@@84 T@T) ($generated@@85 T@U) ($generated@@86 T@U) ($generated@@87 T@U) ($generated@@88 T@U) ) (! (= ($generated@@77 $generated@@82 $generated@@83 $generated@@84 ($generated@@81 $generated@@82 $generated@@83 $generated@@84 $generated@@86 $generated@@87 $generated@@88 $generated@@85) $generated@@87 $generated@@88) $generated@@85)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@89 T@T) ($generated@@90 T@T) ($generated@@91 T@T) ($generated@@92 T@U) ($generated@@93 T@U) ($generated@@94 T@U) ($generated@@95 T@U) ($generated@@96 T@U) ($generated@@97 T@U) ) (!  (or (= $generated@@94 $generated@@96) (= ($generated@@77 $generated@@89 $generated@@90 $generated@@91 ($generated@@81 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@94 $generated@@95 $generated@@92) $generated@@96 $generated@@97) ($generated@@77 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@96 $generated@@97)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@98 T@T) ($generated@@99 T@T) ($generated@@100 T@T) ($generated@@101 T@U) ($generated@@102 T@U) ($generated@@103 T@U) ($generated@@104 T@U) ($generated@@105 T@U) ($generated@@106 T@U) ) (!  (or (= $generated@@104 $generated@@106) (= ($generated@@77 $generated@@98 $generated@@99 $generated@@100 ($generated@@81 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@103 $generated@@104 $generated@@101) $generated@@105 $generated@@106) ($generated@@77 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@105 $generated@@106)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@78) 5)) (= ($generated@@3 $generated@@79) 6)))
(assert (forall (($generated@@107 T@U) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 Bool) ($generated@@111 T@U) ($generated@@112 T@U) ) (! (= ($generated@@8 ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))  (=> (and (or (not (= $generated@@111 $generated@@107)) (not true)) ($generated@@8 ($generated@@22 $generated@@4 ($generated@@30 $generated@@79 $generated@@29 ($generated@@30 $generated@@78 ($generated@@28 $generated@@79 $generated@@29) $generated@@108 $generated@@111) $generated@@109)))) $generated@@110))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@113 () T@U)
(declare-fun $generated@@114 () T@U)
(declare-fun $generated@@115 () T@U)
(declare-fun $generated@@116 () T@U)
(declare-fun $generated@@117 () Real)
(declare-fun $generated@@118 () Real)
(declare-fun $generated@@119 (T@U) Bool)
(declare-fun $generated@@120 () T@U)
(declare-fun $generated@@121 (T@U) Bool)
(declare-fun $generated@@122 () Real)
(declare-fun $generated@@123 () Real)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.leastUse_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 5) (let (($generated@@124  (=> (= $generated@@113 ($generated@@80 $generated@@114 $generated@@115 $generated@@2 false)) (and (=> (= (ControlFlow 0 2) (- 0 4)) ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@117))))) (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@117)))) (=> ($generated@@73 $generated@@116 $generated@@118) (and (=> (= (ControlFlow 0 2) (- 0 3)) (=> ($generated@@73 $generated@@116 $generated@@118) (or ($generated@@72 $generated@@116 $generated@@118) (forall (($generated@@125 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@125)))) (<= $generated@@125 $generated@@118))
 :qid |sourcekerneldfy.4:12|
 :skolemid |554|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@125))))
))))) (=> (=> ($generated@@73 $generated@@116 $generated@@118) (or ($generated@@72 $generated@@116 $generated@@118) (forall (($generated@@126 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@126)))) (<= $generated@@126 $generated@@118))
 :qid |sourcekerneldfy.4:12|
 :skolemid |554|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@126))))
)))) (=> (and (and (and (and ($generated@@119 $generated@@120) ($generated@@121 $generated@@120)) ($generated@@73 $generated@@116 $generated@@122)) (and ($generated@@73 $generated@@116 $generated@@122) (and ($generated@@72 $generated@@116 $generated@@122) (forall (($generated@@127 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@127)))) (<= $generated@@127 $generated@@122))
 :qid |sourcekerneldfy.4:12|
 :skolemid |557|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@127))))
))))) (and (and (forall (($generated@@128 Real) ) (! ($generated@@73 $generated@@116 $generated@@128)
 :qid |sourcekerneldfy.17:20|
 :skolemid |558|
 :pattern ( ($generated@@72 $generated@@116 $generated@@128))
)) (forall (($generated@@129 Real) ) (!  (=> ($generated@@72 $generated@@116 $generated@@129) (<= $generated@@122 $generated@@129))
 :qid |sourcekerneldfy.17:20|
 :skolemid |559|
 :pattern ( ($generated@@72 $generated@@116 $generated@@129))
))) (and (= $generated@@115 $generated@@120) (= (ControlFlow 0 2) (- 0 1))))) (<= $generated@@122 $generated@@123))))))))))
(let (($generated@@130  (=> (and ($generated@@119 $generated@@115) ($generated@@121 $generated@@115)) (=> (and (and ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@116 ($generated@@17 $generated)) ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@116 ($generated@@17 $generated) $generated@@115)) (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@117)))) ($generated@@73 $generated@@116 $generated@@118))) (=> (and (and (and ($generated@@73 $generated@@116 $generated@@118) (and ($generated@@72 $generated@@116 $generated@@118) (forall (($generated@@131 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@131)))) (<= $generated@@131 $generated@@118))
 :qid |sourcekerneldfy.4:12|
 :skolemid |577|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@131))))
)))) ($generated@@73 $generated@@116 $generated@@123)) (and (and ($generated@@73 $generated@@116 $generated@@123) (and ($generated@@72 $generated@@116 $generated@@123) (forall (($generated@@132 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@132)))) (<= $generated@@132 $generated@@123))
 :qid |sourcekerneldfy.4:12|
 :skolemid |579|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@132))))
)))) (= (ControlFlow 0 5) 2))) $generated@@124)))))
$generated@@130)))
))
(check-sat)
(get-info :rlimit)
(pop 1)
; Valid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@22 (T@T T@U) T@U)
(declare-fun $generated@@25 (T@U T@U) Bool)
(declare-fun $generated@@26 (T@T T@U T@U) Bool)
(declare-fun $generated@@28 (T@T T@T) T@T)
(declare-fun $generated@@29 () T@T)
(declare-fun $generated@@30 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@31 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@32 (T@T) T@T)
(declare-fun $generated@@33 (T@T) T@T)
(declare-fun $generated@@56 (T@U T@U T@U) Bool)
(declare-fun $generated@@57 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@72 (T@U Real) Bool)
(declare-fun $generated@@73 (T@U Real) Bool)
(declare-fun $generated@@77 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@78 () T@T)
(declare-fun $generated@@79 () T@T)
(declare-fun $generated@@80 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@81 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@23 T@U) ($generated@@24 T@T) ) (! (= ($generated@@22 $generated@@24 ($generated@@21 $generated@@24 $generated@@23)) $generated@@23)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@21 $generated@@24 $generated@@23))
)))
(assert (forall (($generated@@27 T@U) ) (!  (=> ($generated@@25 $generated@@27 $generated) (and (= ($generated@@21 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27)))) $generated@@27) ($generated@@26 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@22 $generated@@6 $generated@@27))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@25 $generated@@27 $generated))
)))
(assert  (and (and (and (and (and (forall (($generated@@34 T@T) ($generated@@35 T@T) ($generated@@36 T@U) ($generated@@37 T@U) ($generated@@38 T@U) ) (! (= ($generated@@30 $generated@@34 $generated@@35 ($generated@@31 $generated@@34 $generated@@35 $generated@@37 $generated@@38 $generated@@36) $generated@@38) $generated@@36)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@39 T@T) ($generated@@40 T@T) ($generated@@41 T@U) ($generated@@42 T@U) ($generated@@43 T@U) ($generated@@44 T@U) ) (!  (or (= $generated@@43 $generated@@44) (= ($generated@@30 $generated@@39 $generated@@40 ($generated@@31 $generated@@39 $generated@@40 $generated@@42 $generated@@43 $generated@@41) $generated@@44) ($generated@@30 $generated@@39 $generated@@40 $generated@@42 $generated@@44)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@45 T@T) ($generated@@46 T@T) ) (! (= ($generated@@3 ($generated@@28 $generated@@45 $generated@@46)) 3)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@47 T@T) ($generated@@48 T@T) ) (! (= ($generated@@32 ($generated@@28 $generated@@47 $generated@@48)) $generated@@47)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@28 $generated@@47 $generated@@48))
))) (forall (($generated@@49 T@T) ($generated@@50 T@T) ) (! (= ($generated@@33 ($generated@@28 $generated@@49 $generated@@50)) $generated@@50)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@28 $generated@@49 $generated@@50))
))) (= ($generated@@3 $generated@@29) 4)))
(assert (forall (($generated@@51 T@U) ($generated@@52 T@U) ) (!  (=> ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)) (and (= ($generated@@21 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51)) $generated@@51) ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) ($generated@@22 ($generated@@28 $generated@@29 $generated@@4) $generated@@51) ($generated@@17 $generated@@52))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@25 $generated@@51 ($generated@@17 $generated@@52)))
)))
(assert (forall (($generated@@53 T@U) ($generated@@54 T@U) ($generated@@55 T@T) ) (! (= ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54) ($generated@@26 $generated@@55 $generated@@53 $generated@@54))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@25 ($generated@@21 $generated@@55 $generated@@53) $generated@@54))
)))
(assert (forall (($generated@@58 T@U) ($generated@@59 T@U) ($generated@@60 T@U) ($generated@@61 T@T) ) (! (= ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60) ($generated@@57 $generated@@61 $generated@@58 $generated@@59 $generated@@60))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@56 ($generated@@21 $generated@@61 $generated@@58) $generated@@59 $generated@@60))
)))
(assert (forall (($generated@@62 Real) ) (! ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@26 $generated@@6 ($generated@@11 $generated@@62) $generated))
)))
(assert (forall (($generated@@63 T@U) ($generated@@64 T@U) ) (! (= ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)) (forall (($generated@@65 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65)) ($generated@@25 $generated@@65 $generated@@64))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@63 $generated@@65))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@63 ($generated@@17 $generated@@64)))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 Real) ) (! ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@57 $generated@@6 ($generated@@11 $generated@@67) $generated $generated@@66))
)))
(assert (forall (($generated@@68 T@U) ($generated@@69 T@U) ($generated@@70 T@U) ) (! (= ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70) (forall (($generated@@71 T@U) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71)) ($generated@@56 $generated@@71 $generated@@69 $generated@@70))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@68 $generated@@71))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@68 ($generated@@17 $generated@@69) $generated@@70))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (!  (=> ($generated@@73 $generated@@74 $generated@@75) (= ($generated@@72 $generated@@74 $generated@@75) (forall (($generated@@76 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76)))) (<= $generated@@76 $generated@@75))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@74 ($generated@@21 $generated@@6 ($generated@@11 $generated@@76))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@72 $generated@@74 $generated@@75))
)))
(assert  (and (and (and (forall (($generated@@82 T@T) ($generated@@83 T@T) ($generated@@84 T@T) ($generated@@85 T@U) ($generated@@86 T@U) ($generated@@87 T@U) ($generated@@88 T@U) ) (! (= ($generated@@77 $generated@@82 $generated@@83 $generated@@84 ($generated@@81 $generated@@82 $generated@@83 $generated@@84 $generated@@86 $generated@@87 $generated@@88 $generated@@85) $generated@@87 $generated@@88) $generated@@85)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@89 T@T) ($generated@@90 T@T) ($generated@@91 T@T) ($generated@@92 T@U) ($generated@@93 T@U) ($generated@@94 T@U) ($generated@@95 T@U) ($generated@@96 T@U) ($generated@@97 T@U) ) (!  (or (= $generated@@94 $generated@@96) (= ($generated@@77 $generated@@89 $generated@@90 $generated@@91 ($generated@@81 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@94 $generated@@95 $generated@@92) $generated@@96 $generated@@97) ($generated@@77 $generated@@89 $generated@@90 $generated@@91 $generated@@93 $generated@@96 $generated@@97)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@98 T@T) ($generated@@99 T@T) ($generated@@100 T@T) ($generated@@101 T@U) ($generated@@102 T@U) ($generated@@103 T@U) ($generated@@104 T@U) ($generated@@105 T@U) ($generated@@106 T@U) ) (!  (or (= $generated@@104 $generated@@106) (= ($generated@@77 $generated@@98 $generated@@99 $generated@@100 ($generated@@81 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@103 $generated@@104 $generated@@101) $generated@@105 $generated@@106) ($generated@@77 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@105 $generated@@106)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@78) 5)) (= ($generated@@3 $generated@@79) 6)))
(assert (forall (($generated@@107 T@U) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 Bool) ($generated@@111 T@U) ($generated@@112 T@U) ) (! (= ($generated@@8 ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))  (=> (and (or (not (= $generated@@111 $generated@@107)) (not true)) ($generated@@8 ($generated@@22 $generated@@4 ($generated@@30 $generated@@79 $generated@@29 ($generated@@30 $generated@@78 ($generated@@28 $generated@@79 $generated@@29) $generated@@108 $generated@@111) $generated@@109)))) $generated@@110))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@77 $generated@@78 $generated@@79 $generated@@4 ($generated@@80 $generated@@107 $generated@@108 $generated@@109 $generated@@110) $generated@@111 $generated@@112))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@113 () T@U)
(declare-fun $generated@@114 () T@U)
(declare-fun $generated@@115 () T@U)
(declare-fun $generated@@116 () T@U)
(declare-fun $generated@@117 () Real)
(declare-fun $generated@@118 () Real)
(declare-fun $generated@@119 (T@U) Bool)
(declare-fun $generated@@120 () T@U)
(declare-fun $generated@@121 (T@U) Bool)
(declare-fun $generated@@122 () Real)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.existsUse_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 5) (let (($generated@@123  (=> (= $generated@@113 ($generated@@80 $generated@@114 $generated@@115 $generated@@2 false)) (and (=> (= (ControlFlow 0 2) (- 0 4)) ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@117))))) (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@117)))) (=> ($generated@@73 $generated@@116 $generated@@118) (and (=> (= (ControlFlow 0 2) (- 0 3)) (=> ($generated@@73 $generated@@116 $generated@@118) (or ($generated@@72 $generated@@116 $generated@@118) (forall (($generated@@124 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@124)))) (<= $generated@@124 $generated@@118))
 :qid |sourcekerneldfy.4:12|
 :skolemid |554|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@124))))
))))) (=> (=> ($generated@@73 $generated@@116 $generated@@118) (or ($generated@@72 $generated@@116 $generated@@118) (forall (($generated@@125 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@125)))) (<= $generated@@125 $generated@@118))
 :qid |sourcekerneldfy.4:12|
 :skolemid |554|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@125))))
)))) (=> (and (and ($generated@@119 $generated@@120) ($generated@@121 $generated@@120)) ($generated@@73 $generated@@116 $generated@@122)) (=> (and (and (and ($generated@@73 $generated@@116 $generated@@122) (and ($generated@@72 $generated@@116 $generated@@122) (forall (($generated@@126 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@126)))) (<= $generated@@126 $generated@@122))
 :qid |sourcekerneldfy.4:12|
 :skolemid |557|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@126))))
)))) (forall (($generated@@127 Real) ) (! ($generated@@73 $generated@@116 $generated@@127)
 :qid |sourcekerneldfy.17:20|
 :skolemid |558|
 :pattern ( ($generated@@72 $generated@@116 $generated@@127))
))) (and (and (forall (($generated@@128 Real) ) (!  (=> ($generated@@72 $generated@@116 $generated@@128) (<= $generated@@122 $generated@@128))
 :qid |sourcekerneldfy.17:20|
 :skolemid |559|
 :pattern ( ($generated@@72 $generated@@116 $generated@@128))
)) (= $generated@@115 $generated@@120)) (and (forall (($generated@@129 Real) ) (!  (and ($generated@@73 $generated@@116 $generated@@129) (=> ($generated@@72 $generated@@116 $generated@@129) (forall (($generated@@130 Real) ) (! ($generated@@73 $generated@@116 $generated@@130)
 :qid |sourcekerneldfy.39:53|
 :skolemid |590|
 :pattern ( ($generated@@72 $generated@@116 $generated@@130))
))))
 :qid |sourcekerneldfy.39:20|
 :skolemid |591|
 :pattern ( ($generated@@72 $generated@@116 $generated@@129))
)) (= (ControlFlow 0 2) (- 0 1))))) (exists (($generated@@131 Real) ) (!  (and ($generated@@72 $generated@@116 $generated@@131) (forall (($generated@@132 Real) ) (!  (=> ($generated@@72 $generated@@116 $generated@@132) (<= $generated@@131 $generated@@132))
 :qid |sourcekerneldfy.39:53|
 :skolemid |592|
 :pattern ( ($generated@@72 $generated@@116 $generated@@132))
)))
 :qid |sourcekerneldfy.39:20|
 :skolemid |593|
 :pattern ( ($generated@@72 $generated@@116 $generated@@131))
))))))))))))
(let (($generated@@133  (=> (and ($generated@@119 $generated@@115) ($generated@@121 $generated@@115)) (=> (and (and (and ($generated@@26 ($generated@@28 $generated@@29 $generated@@4) $generated@@116 ($generated@@17 $generated)) ($generated@@57 ($generated@@28 $generated@@29 $generated@@4) $generated@@116 ($generated@@17 $generated) $generated@@115)) (and ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@117)))) ($generated@@73 $generated@@116 $generated@@118))) (and (and ($generated@@73 $generated@@116 $generated@@118) (and ($generated@@72 $generated@@116 $generated@@118) (forall (($generated@@134 Real) ) (!  (=> ($generated@@8 ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@134)))) (<= $generated@@134 $generated@@118))
 :qid |sourcekerneldfy.4:12|
 :skolemid |589|
 :pattern ( ($generated@@30 $generated@@29 $generated@@4 $generated@@116 ($generated@@21 $generated@@6 ($generated@@11 $generated@@134))))
)))) (= (ControlFlow 0 5) 2))) $generated@@123))))
$generated@@133)))
))
(check-sat)
(get-info :rlimit)
(pop 1)
; Valid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@24 (T@T T@U) T@U)
(declare-fun $generated@@25 () T@T)
(declare-fun $generated@@28 (Real) Real)
(declare-fun $generated@@31 (T@T T@U) T@U)
(declare-fun $generated@@34 (T@U T@U) Bool)
(declare-fun $generated@@35 (T@T T@U T@U) Bool)
(declare-fun $generated@@37 (T@T T@T) T@T)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@T) T@T)
(declare-fun $generated@@41 (T@T) T@T)
(declare-fun $generated@@64 (T@U T@U T@U) Bool)
(declare-fun $generated@@65 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@80 () T@U)
(declare-fun $generated@@82 (T@U T@U) T@U)
(declare-fun $generated@@91 (T@U Real) Bool)
(declare-fun $generated@@92 (T@U Real) Bool)
(declare-fun $generated@@102 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@103 () T@T)
(declare-fun $generated@@104 () T@T)
(declare-fun $generated@@105 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@106 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@22 T@U) ($generated@@23 T@T) ) (! (= ($generated@@21 $generated@@23 $generated@@22) $generated@@22)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@21 $generated@@23 $generated@@22))
)))
(assert (= ($generated@@3 $generated@@25) 3))
(assert (forall (($generated@@26 T@U) ($generated@@27 T@T) ) (! (= ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)) ($generated@@21 $generated@@25 ($generated@@24 $generated@@27 $generated@@26)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)))
)))
(assert (forall (($generated@@29 Real) ) (! (= ($generated@@28 $generated@@29) $generated@@29)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@28 $generated@@29))
)))
(assert (forall (($generated@@30 Real) ) (! (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))) ($generated@@21 $generated@@25 ($generated@@24 $generated@@6 ($generated@@11 $generated@@30))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@T) ) (! (= ($generated@@31 $generated@@33 ($generated@@24 $generated@@33 $generated@@32)) $generated@@32)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@24 $generated@@33 $generated@@32))
)))
(assert (forall (($generated@@36 T@U) ) (!  (=> ($generated@@34 $generated@@36 $generated) (and (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36)))) $generated@@36) ($generated@@35 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@34 $generated@@36 $generated))
)))
(assert  (and (and (and (and (forall (($generated@@42 T@T) ($generated@@43 T@T) ($generated@@44 T@U) ($generated@@45 T@U) ($generated@@46 T@U) ) (! (= ($generated@@38 $generated@@42 $generated@@43 ($generated@@39 $generated@@42 $generated@@43 $generated@@45 $generated@@46 $generated@@44) $generated@@46) $generated@@44)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@47 T@T) ($generated@@48 T@T) ($generated@@49 T@U) ($generated@@50 T@U) ($generated@@51 T@U) ($generated@@52 T@U) ) (!  (or (= $generated@@51 $generated@@52) (= ($generated@@38 $generated@@47 $generated@@48 ($generated@@39 $generated@@47 $generated@@48 $generated@@50 $generated@@51 $generated@@49) $generated@@52) ($generated@@38 $generated@@47 $generated@@48 $generated@@50 $generated@@52)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@3 ($generated@@37 $generated@@53 $generated@@54)) 4)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@40 ($generated@@37 $generated@@55 $generated@@56)) $generated@@55)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@37 $generated@@55 $generated@@56))
))) (forall (($generated@@57 T@T) ($generated@@58 T@T) ) (! (= ($generated@@41 ($generated@@37 $generated@@57 $generated@@58)) $generated@@58)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@37 $generated@@57 $generated@@58))
))))
(assert (forall (($generated@@59 T@U) ($generated@@60 T@U) ) (!  (=> ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)) (and (= ($generated@@24 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59)) $generated@@59) ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59) ($generated@@17 $generated@@60))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)))
)))
(assert (forall (($generated@@61 T@U) ($generated@@62 T@U) ($generated@@63 T@T) ) (! (= ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62) ($generated@@35 $generated@@63 $generated@@61 $generated@@62))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 T@U) ($generated@@68 T@U) ($generated@@69 T@T) ) (! (= ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68) ($generated@@65 $generated@@69 $generated@@66 $generated@@67 $generated@@68))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68))
)))
(assert (forall (($generated@@70 Real) ) (! ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated))
)))
(assert (forall (($generated@@71 T@U) ($generated@@72 T@U) ) (! (= ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)) (forall (($generated@@73 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73)) ($generated@@34 $generated@@73 $generated@@72))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (! ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74))
)))
(assert (forall (($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ) (! (= ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78) (forall (($generated@@79 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79)) ($generated@@64 $generated@@79 $generated@@77 $generated@@78))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78))
)))
(assert (forall (($generated@@81 T@U) ) (!  (not ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81)))
 :qid |DafnyPreludebpl.837:15|
 :skolemid |155|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81))
)))
(assert (forall (($generated@@83 T@U) ($generated@@84 T@U) ($generated@@85 T@U) ) (! (= ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@83 $generated@@84) $generated@@85))  (or (= $generated@@85 $generated@@84) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@83 $generated@@85))))
 :qid |DafnyPreludebpl.845:15|
 :skolemid |157|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@83 $generated@@84) $generated@@85))
)))
(assert (forall (($generated@@86 T@U) ($generated@@87 T@U) ) (! ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@86 $generated@@87) $generated@@87))
 :qid |DafnyPreludebpl.847:15|
 :skolemid |158|
 :pattern ( ($generated@@82 $generated@@86 $generated@@87))
)))
(assert (forall (($generated@@88 T@U) ($generated@@89 T@U) ($generated@@90 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@88 $generated@@90)) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@82 $generated@@88 $generated@@89) $generated@@90)))
 :qid |DafnyPreludebpl.849:15|
 :skolemid |159|
 :pattern ( ($generated@@82 $generated@@88 $generated@@89) ($generated@@38 $generated@@25 $generated@@4 $generated@@88 $generated@@90))
)))
(assert (forall (($generated@@93 T@U) ($generated@@94 Real) ) (!  (=> ($generated@@92 $generated@@93 $generated@@94) (= ($generated@@91 $generated@@93 $generated@@94) (forall (($generated@@95 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@93 ($generated@@24 $generated@@6 ($generated@@11 $generated@@95)))) (<= $generated@@95 $generated@@94))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@93 ($generated@@24 $generated@@6 ($generated@@11 $generated@@95))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@91 $generated@@93 $generated@@94))
)))
(assert (forall (($generated@@96 T@U) ($generated@@97 Real) ) (!  (=> ($generated@@92 $generated@@96 ($generated@@28 $generated@@97)) (= ($generated@@91 $generated@@96 ($generated@@28 $generated@@97)) (forall (($generated@@98 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@96 ($generated@@24 $generated@@6 ($generated@@11 $generated@@98)))) (<= $generated@@98 ($generated@@28 $generated@@97)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |540|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@96 ($generated@@24 $generated@@6 ($generated@@11 $generated@@98))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |541|
 :pattern ( ($generated@@91 $generated@@96 ($generated@@28 $generated@@97)))
)))
(assert (forall (($generated@@99 T@U) ($generated@@100 Real) ) (!  (=> ($generated@@92 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@28 $generated@@100)) (= ($generated@@91 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@28 $generated@@100)) (forall (($generated@@101 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@24 $generated@@6 ($generated@@11 $generated@@101)))) (<= $generated@@101 ($generated@@28 $generated@@100)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |542|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@99 ($generated@@24 $generated@@6 ($generated@@11 $generated@@101))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |543|
 :pattern ( ($generated@@91 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@99) ($generated@@28 $generated@@100)))
)))
(assert  (and (and (and (forall (($generated@@107 T@T) ($generated@@108 T@T) ($generated@@109 T@T) ($generated@@110 T@U) ($generated@@111 T@U) ($generated@@112 T@U) ($generated@@113 T@U) ) (! (= ($generated@@102 $generated@@107 $generated@@108 $generated@@109 ($generated@@106 $generated@@107 $generated@@108 $generated@@109 $generated@@111 $generated@@112 $generated@@113 $generated@@110) $generated@@112 $generated@@113) $generated@@110)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@114 T@T) ($generated@@115 T@T) ($generated@@116 T@T) ($generated@@117 T@U) ($generated@@118 T@U) ($generated@@119 T@U) ($generated@@120 T@U) ($generated@@121 T@U) ($generated@@122 T@U) ) (!  (or (= $generated@@119 $generated@@121) (= ($generated@@102 $generated@@114 $generated@@115 $generated@@116 ($generated@@106 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@119 $generated@@120 $generated@@117) $generated@@121 $generated@@122) ($generated@@102 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@121 $generated@@122)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@123 T@T) ($generated@@124 T@T) ($generated@@125 T@T) ($generated@@126 T@U) ($generated@@127 T@U) ($generated@@128 T@U) ($generated@@129 T@U) ($generated@@130 T@U) ($generated@@131 T@U) ) (!  (or (= $generated@@129 $generated@@131) (= ($generated@@102 $generated@@123 $generated@@124 $generated@@125 ($generated@@106 $generated@@123 $generated@@124 $generated@@125 $generated@@127 $generated@@128 $generated@@129 $generated@@126) $generated@@130 $generated@@131) ($generated@@102 $generated@@123 $generated@@124 $generated@@125 $generated@@127 $generated@@130 $generated@@131)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@103) 5)) (= ($generated@@3 $generated@@104) 6)))
(assert (forall (($generated@@132 T@U) ($generated@@133 T@U) ($generated@@134 T@U) ($generated@@135 Bool) ($generated@@136 T@U) ($generated@@137 T@U) ) (! (= ($generated@@8 ($generated@@102 $generated@@103 $generated@@104 $generated@@4 ($generated@@105 $generated@@132 $generated@@133 $generated@@134 $generated@@135) $generated@@136 $generated@@137))  (=> (and (or (not (= $generated@@136 $generated@@132)) (not true)) ($generated@@8 ($generated@@31 $generated@@4 ($generated@@38 $generated@@104 $generated@@25 ($generated@@38 $generated@@103 ($generated@@37 $generated@@104 $generated@@25) $generated@@133 $generated@@136) $generated@@134)))) $generated@@135))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@102 $generated@@103 $generated@@104 $generated@@4 ($generated@@105 $generated@@132 $generated@@133 $generated@@134 $generated@@135) $generated@@136 $generated@@137))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@138 () T@U)
(declare-fun $generated@@139 () T@U)
(declare-fun $generated@@140 () T@U)
(declare-fun $generated@@141 () T@U)
(declare-fun $generated@@142 () Real)
(declare-fun $generated@@143 () Real)
(declare-fun $generated@@144 () Real)
(declare-fun $generated@@145 (T@U) Bool)
(declare-fun $generated@@146 () T@U)
(declare-fun $generated@@147 (T@U) Bool)
(declare-fun $generated@@148 () Real)
(declare-fun $generated@@149 () Real)
(declare-fun $generated@@150 () T@U)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.singletonFalse_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 6) (let (($generated@@151  (=> (= $generated@@138 ($generated@@105 $generated@@139 $generated@@140 $generated@@2 false)) (=> (and (= $generated@@141 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) ($generated@@82 $generated@@80 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 0.0)))))) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@141 ($generated@@17 $generated) $generated@@140)) (=> (and (and (= $generated@@142 ($generated@@28 1.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@142) $generated $generated@@140)) (and ($generated@@92 $generated@@141 ($generated@@28 1.0)) ($generated@@92 $generated@@141 ($generated@@28 1.0)))) (and (=> (= (ControlFlow 0 2) (- 0 5)) (=> ($generated@@92 $generated@@141 ($generated@@28 1.0)) (or ($generated@@91 $generated@@141 ($generated@@28 1.0)) (forall (($generated@@152 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@152)))) (<= $generated@@152 ($generated@@28 1.0)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |595|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@152))))
))))) (=> ($generated@@91 $generated@@141 ($generated@@28 1.0)) (=> (and (= $generated@@143 ($generated@@28 0.0)) (= $generated@@144 ($generated@@28 1.0))) (=> (and (and ($generated@@145 $generated@@146) ($generated@@147 $generated@@146)) (and (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) (and ($generated@@92 $generated@@141 $generated@@144) (=> ($generated@@91 $generated@@141 $generated@@144) ($generated@@92 $generated@@141 $generated@@148)))) (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) ($generated@@91 $generated@@141 $generated@@144)) (and ($generated@@92 $generated@@141 $generated@@148) (and ($generated@@91 $generated@@141 $generated@@148) (forall (($generated@@153 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@153)))) (<= $generated@@153 $generated@@148))
 :qid |sourcekerneldfy.4:12|
 :skolemid |550|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@153))))
))))))) (=> (and (and (and (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) (and ($generated@@92 $generated@@141 $generated@@144) (=> ($generated@@91 $generated@@141 $generated@@144) (forall (($generated@@154 Real) ) (! ($generated@@92 $generated@@141 $generated@@154)
 :qid |sourcekerneldfy.11:14|
 :skolemid |551|
 :pattern ( ($generated@@91 $generated@@141 $generated@@154))
))))) (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) ($generated@@91 $generated@@141 $generated@@144)) (forall (($generated@@155 Real) ) (!  (=> ($generated@@91 $generated@@141 $generated@@155) (<= $generated@@148 $generated@@155))
 :qid |sourcekerneldfy.11:14|
 :skolemid |552|
 :pattern ( ($generated@@91 $generated@@141 $generated@@155))
)))) (and (= $generated@@140 $generated@@146) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@141 ($generated@@17 $generated) $generated@@146))) (and (and (= $generated@@149 ($generated@@28 0.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@149) $generated $generated@@146)) (and ($generated@@92 $generated@@141 ($generated@@28 0.0)) ($generated@@92 $generated@@141 ($generated@@28 0.0))))) (and (=> (= (ControlFlow 0 2) (- 0 4)) (=> ($generated@@92 $generated@@141 ($generated@@28 0.0)) (or ($generated@@91 $generated@@141 ($generated@@28 0.0)) (forall (($generated@@156 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@156)))) (<= $generated@@156 ($generated@@28 0.0)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |598|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@141 ($generated@@24 $generated@@6 ($generated@@11 $generated@@156))))
))))) (=> ($generated@@91 $generated@@141 ($generated@@28 0.0)) (and (=> (= (ControlFlow 0 2) (- 0 3)) (= $generated@@148 ($generated@@28 0.0))) (=> (= $generated@@148 ($generated@@28 0.0)) (=> (= (ControlFlow 0 2) (- 0 1)) ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 false))))))))))))))))))
(let (($generated@@157  (=> (and ($generated@@145 $generated@@140) ($generated@@147 $generated@@140)) (=> (and (and (and ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@150 ($generated@@17 $generated)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@150 ($generated@@17 $generated) $generated@@140)) true) (= (ControlFlow 0 6) 2)) $generated@@151))))
$generated@@157)))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 2) (- 1))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@24 (T@T T@U) T@U)
(declare-fun $generated@@25 () T@T)
(declare-fun $generated@@28 (Real) Real)
(declare-fun $generated@@31 (T@T T@U) T@U)
(declare-fun $generated@@34 (T@U T@U) Bool)
(declare-fun $generated@@35 (T@T T@U T@U) Bool)
(declare-fun $generated@@37 (T@T T@T) T@T)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@T) T@T)
(declare-fun $generated@@41 (T@T) T@T)
(declare-fun $generated@@64 (T@U T@U T@U) Bool)
(declare-fun $generated@@65 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@80 () T@U)
(declare-fun $generated@@82 (T@U Real) Bool)
(declare-fun $generated@@83 (T@U Real) Bool)
(declare-fun $generated@@93 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@94 () T@T)
(declare-fun $generated@@95 () T@T)
(declare-fun $generated@@96 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@97 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@22 T@U) ($generated@@23 T@T) ) (! (= ($generated@@21 $generated@@23 $generated@@22) $generated@@22)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@21 $generated@@23 $generated@@22))
)))
(assert (= ($generated@@3 $generated@@25) 3))
(assert (forall (($generated@@26 T@U) ($generated@@27 T@T) ) (! (= ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)) ($generated@@21 $generated@@25 ($generated@@24 $generated@@27 $generated@@26)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)))
)))
(assert (forall (($generated@@29 Real) ) (! (= ($generated@@28 $generated@@29) $generated@@29)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@28 $generated@@29))
)))
(assert (forall (($generated@@30 Real) ) (! (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))) ($generated@@21 $generated@@25 ($generated@@24 $generated@@6 ($generated@@11 $generated@@30))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@T) ) (! (= ($generated@@31 $generated@@33 ($generated@@24 $generated@@33 $generated@@32)) $generated@@32)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@24 $generated@@33 $generated@@32))
)))
(assert (forall (($generated@@36 T@U) ) (!  (=> ($generated@@34 $generated@@36 $generated) (and (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36)))) $generated@@36) ($generated@@35 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@34 $generated@@36 $generated))
)))
(assert  (and (and (and (and (forall (($generated@@42 T@T) ($generated@@43 T@T) ($generated@@44 T@U) ($generated@@45 T@U) ($generated@@46 T@U) ) (! (= ($generated@@38 $generated@@42 $generated@@43 ($generated@@39 $generated@@42 $generated@@43 $generated@@45 $generated@@46 $generated@@44) $generated@@46) $generated@@44)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@47 T@T) ($generated@@48 T@T) ($generated@@49 T@U) ($generated@@50 T@U) ($generated@@51 T@U) ($generated@@52 T@U) ) (!  (or (= $generated@@51 $generated@@52) (= ($generated@@38 $generated@@47 $generated@@48 ($generated@@39 $generated@@47 $generated@@48 $generated@@50 $generated@@51 $generated@@49) $generated@@52) ($generated@@38 $generated@@47 $generated@@48 $generated@@50 $generated@@52)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@3 ($generated@@37 $generated@@53 $generated@@54)) 4)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@40 ($generated@@37 $generated@@55 $generated@@56)) $generated@@55)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@37 $generated@@55 $generated@@56))
))) (forall (($generated@@57 T@T) ($generated@@58 T@T) ) (! (= ($generated@@41 ($generated@@37 $generated@@57 $generated@@58)) $generated@@58)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@37 $generated@@57 $generated@@58))
))))
(assert (forall (($generated@@59 T@U) ($generated@@60 T@U) ) (!  (=> ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)) (and (= ($generated@@24 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59)) $generated@@59) ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59) ($generated@@17 $generated@@60))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)))
)))
(assert (forall (($generated@@61 T@U) ($generated@@62 T@U) ($generated@@63 T@T) ) (! (= ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62) ($generated@@35 $generated@@63 $generated@@61 $generated@@62))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 T@U) ($generated@@68 T@U) ($generated@@69 T@T) ) (! (= ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68) ($generated@@65 $generated@@69 $generated@@66 $generated@@67 $generated@@68))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68))
)))
(assert (forall (($generated@@70 Real) ) (! ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated))
)))
(assert (forall (($generated@@71 T@U) ($generated@@72 T@U) ) (! (= ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)) (forall (($generated@@73 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73)) ($generated@@34 $generated@@73 $generated@@72))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (! ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74))
)))
(assert (forall (($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ) (! (= ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78) (forall (($generated@@79 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79)) ($generated@@64 $generated@@79 $generated@@77 $generated@@78))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78))
)))
(assert (forall (($generated@@81 T@U) ) (!  (not ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81)))
 :qid |DafnyPreludebpl.837:15|
 :skolemid |155|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@80 $generated@@81))
)))
(assert (forall (($generated@@84 T@U) ($generated@@85 Real) ) (!  (=> ($generated@@83 $generated@@84 $generated@@85) (= ($generated@@82 $generated@@84 $generated@@85) (forall (($generated@@86 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@84 ($generated@@24 $generated@@6 ($generated@@11 $generated@@86)))) (<= $generated@@86 $generated@@85))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@84 ($generated@@24 $generated@@6 ($generated@@11 $generated@@86))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@82 $generated@@84 $generated@@85))
)))
(assert (forall (($generated@@87 T@U) ($generated@@88 Real) ) (!  (=> ($generated@@83 $generated@@87 ($generated@@28 $generated@@88)) (= ($generated@@82 $generated@@87 ($generated@@28 $generated@@88)) (forall (($generated@@89 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@87 ($generated@@24 $generated@@6 ($generated@@11 $generated@@89)))) (<= $generated@@89 ($generated@@28 $generated@@88)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |540|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@87 ($generated@@24 $generated@@6 ($generated@@11 $generated@@89))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |541|
 :pattern ( ($generated@@82 $generated@@87 ($generated@@28 $generated@@88)))
)))
(assert (forall (($generated@@90 T@U) ($generated@@91 Real) ) (!  (=> ($generated@@83 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@28 $generated@@91)) (= ($generated@@82 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@28 $generated@@91)) (forall (($generated@@92 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@24 $generated@@6 ($generated@@11 $generated@@92)))) (<= $generated@@92 ($generated@@28 $generated@@91)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |542|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@90 ($generated@@24 $generated@@6 ($generated@@11 $generated@@92))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |543|
 :pattern ( ($generated@@82 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@90) ($generated@@28 $generated@@91)))
)))
(assert  (and (and (and (forall (($generated@@98 T@T) ($generated@@99 T@T) ($generated@@100 T@T) ($generated@@101 T@U) ($generated@@102 T@U) ($generated@@103 T@U) ($generated@@104 T@U) ) (! (= ($generated@@93 $generated@@98 $generated@@99 $generated@@100 ($generated@@97 $generated@@98 $generated@@99 $generated@@100 $generated@@102 $generated@@103 $generated@@104 $generated@@101) $generated@@103 $generated@@104) $generated@@101)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@105 T@T) ($generated@@106 T@T) ($generated@@107 T@T) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 T@U) ($generated@@111 T@U) ($generated@@112 T@U) ($generated@@113 T@U) ) (!  (or (= $generated@@110 $generated@@112) (= ($generated@@93 $generated@@105 $generated@@106 $generated@@107 ($generated@@97 $generated@@105 $generated@@106 $generated@@107 $generated@@109 $generated@@110 $generated@@111 $generated@@108) $generated@@112 $generated@@113) ($generated@@93 $generated@@105 $generated@@106 $generated@@107 $generated@@109 $generated@@112 $generated@@113)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@114 T@T) ($generated@@115 T@T) ($generated@@116 T@T) ($generated@@117 T@U) ($generated@@118 T@U) ($generated@@119 T@U) ($generated@@120 T@U) ($generated@@121 T@U) ($generated@@122 T@U) ) (!  (or (= $generated@@120 $generated@@122) (= ($generated@@93 $generated@@114 $generated@@115 $generated@@116 ($generated@@97 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@119 $generated@@120 $generated@@117) $generated@@121 $generated@@122) ($generated@@93 $generated@@114 $generated@@115 $generated@@116 $generated@@118 $generated@@121 $generated@@122)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@94) 5)) (= ($generated@@3 $generated@@95) 6)))
(assert (forall (($generated@@123 T@U) ($generated@@124 T@U) ($generated@@125 T@U) ($generated@@126 Bool) ($generated@@127 T@U) ($generated@@128 T@U) ) (! (= ($generated@@8 ($generated@@93 $generated@@94 $generated@@95 $generated@@4 ($generated@@96 $generated@@123 $generated@@124 $generated@@125 $generated@@126) $generated@@127 $generated@@128))  (=> (and (or (not (= $generated@@127 $generated@@123)) (not true)) ($generated@@8 ($generated@@31 $generated@@4 ($generated@@38 $generated@@95 $generated@@25 ($generated@@38 $generated@@94 ($generated@@37 $generated@@95 $generated@@25) $generated@@124 $generated@@127) $generated@@125)))) $generated@@126))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@93 $generated@@94 $generated@@95 $generated@@4 ($generated@@96 $generated@@123 $generated@@124 $generated@@125 $generated@@126) $generated@@127 $generated@@128))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@129 () T@U)
(declare-fun $generated@@130 () T@U)
(declare-fun $generated@@131 () T@U)
(declare-fun $generated@@132 () T@U)
(declare-fun $generated@@133 () Real)
(declare-fun $generated@@134 () Real)
(declare-fun $generated@@135 () Real)
(declare-fun $generated@@136 (T@U) Bool)
(declare-fun $generated@@137 () T@U)
(declare-fun $generated@@138 (T@U) Bool)
(declare-fun $generated@@139 () Real)
(declare-fun $generated@@140 () T@U)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.emptyFalse_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 4) (let (($generated@@141  (=> (= $generated@@129 ($generated@@96 $generated@@130 $generated@@131 $generated@@2 false)) (=> (and (= $generated@@132 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@80)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@132 ($generated@@17 $generated) $generated@@131)) (=> (and (and (= $generated@@133 ($generated@@28 0.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@133) $generated $generated@@131)) (and ($generated@@83 $generated@@132 ($generated@@28 0.0)) ($generated@@83 $generated@@132 ($generated@@28 0.0)))) (and (=> (= (ControlFlow 0 2) (- 0 3)) (=> ($generated@@83 $generated@@132 ($generated@@28 0.0)) (or ($generated@@82 $generated@@132 ($generated@@28 0.0)) (forall (($generated@@142 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@142)))) (<= $generated@@142 ($generated@@28 0.0)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |600|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@142))))
))))) (=> ($generated@@82 $generated@@132 ($generated@@28 0.0)) (=> (and (= $generated@@134 ($generated@@28 0.0)) (= $generated@@135 ($generated@@28 0.0))) (=> (and (and (and ($generated@@136 $generated@@137) ($generated@@138 $generated@@137)) (and (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) (and ($generated@@83 $generated@@132 $generated@@135) (=> ($generated@@82 $generated@@132 $generated@@135) ($generated@@83 $generated@@132 $generated@@139)))) (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) ($generated@@82 $generated@@132 $generated@@135)) (and ($generated@@83 $generated@@132 $generated@@139) (and ($generated@@82 $generated@@132 $generated@@139) (forall (($generated@@143 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143)))) (<= $generated@@143 $generated@@139))
 :qid |sourcekerneldfy.4:12|
 :skolemid |550|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@143))))
))))))) (and (and (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) (and ($generated@@83 $generated@@132 $generated@@135) (=> ($generated@@82 $generated@@132 $generated@@135) (forall (($generated@@144 Real) ) (! ($generated@@83 $generated@@132 $generated@@144)
 :qid |sourcekerneldfy.11:14|
 :skolemid |551|
 :pattern ( ($generated@@82 $generated@@132 $generated@@144))
))))) (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@132 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) ($generated@@82 $generated@@132 $generated@@135)) (forall (($generated@@145 Real) ) (!  (=> ($generated@@82 $generated@@132 $generated@@145) (<= $generated@@139 $generated@@145))
 :qid |sourcekerneldfy.11:14|
 :skolemid |552|
 :pattern ( ($generated@@82 $generated@@132 $generated@@145))
)))) (and (= $generated@@131 $generated@@137) (= (ControlFlow 0 2) (- 0 1))))) ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 false))))))))))))
(let (($generated@@146  (=> (and ($generated@@136 $generated@@131) ($generated@@138 $generated@@131)) (=> (and (and (and ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@140 ($generated@@17 $generated)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@140 ($generated@@17 $generated) $generated@@131)) true) (= (ControlFlow 0 4) 2)) $generated@@141))))
$generated@@146)))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 2) (- 1))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 () T@U)
(declare-fun $generated@@3 (T@T) Int)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 () T@T)
(declare-fun $generated@@7 (Bool) T@U)
(declare-fun $generated@@8 (T@U) Bool)
(declare-fun $generated@@9 (Int) T@U)
(declare-fun $generated@@10 (T@U) Int)
(declare-fun $generated@@11 (Real) T@U)
(declare-fun $generated@@12 (T@U) Real)
(declare-fun $generated@@16 (T@U) T@U)
(declare-fun $generated@@17 (T@U) T@U)
(declare-fun $generated@@18 (T@U) T@U)
(declare-fun $generated@@21 (T@T T@U) T@U)
(declare-fun $generated@@24 (T@T T@U) T@U)
(declare-fun $generated@@25 () T@T)
(declare-fun $generated@@28 (Real) Real)
(declare-fun $generated@@31 (T@T T@U) T@U)
(declare-fun $generated@@34 (T@U T@U) Bool)
(declare-fun $generated@@35 (T@T T@U T@U) Bool)
(declare-fun $generated@@37 (T@T T@T) T@T)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@T) T@T)
(declare-fun $generated@@41 (T@T) T@T)
(declare-fun $generated@@64 (T@U T@U T@U) Bool)
(declare-fun $generated@@65 (T@T T@U T@U T@U) Bool)
(declare-fun $generated@@80 (T@U Real) Bool)
(declare-fun $generated@@81 (T@U Real) Bool)
(declare-fun $generated@@91 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@92 () T@T)
(declare-fun $generated@@93 () T@T)
(declare-fun $generated@@94 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@95 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(declare-fun $generated@@127 (T@U Bool) T@U)
(assert  (and (and (and (and (and (= ($generated@@3 $generated@@4) 0) (= ($generated@@3 $generated@@5) 1)) (= ($generated@@3 $generated@@6) 2)) (forall (($generated@@13 Bool) ) (! (= ($generated@@8 ($generated@@7 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@7 $generated@@13))
))) (forall (($generated@@14 Int) ) (! (= ($generated@@10 ($generated@@9 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@9 $generated@@14))
))) (forall (($generated@@15 Real) ) (! (= ($generated@@12 ($generated@@11 $generated@@15)) $generated@@15)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@11 $generated@@15))
))))
(assert (distinct $generated $generated@@0 $generated@@1 $generated@@2)
)
(assert (= ($generated@@16 $generated) $generated@@0))
(assert (forall (($generated@@19 T@U) ) (! (= ($generated@@18 ($generated@@17 $generated@@19)) $generated@@19)
 :qid |DafnyPreludebpl.48:15|
 :skolemid |3|
 :pattern ( ($generated@@17 $generated@@19))
)))
(assert (forall (($generated@@20 T@U) ) (! (= ($generated@@16 ($generated@@17 $generated@@20)) $generated@@1)
 :qid |DafnyPreludebpl.49:15|
 :skolemid |4|
 :pattern ( ($generated@@17 $generated@@20))
)))
(assert (forall (($generated@@22 T@U) ($generated@@23 T@T) ) (! (= ($generated@@21 $generated@@23 $generated@@22) $generated@@22)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@21 $generated@@23 $generated@@22))
)))
(assert (= ($generated@@3 $generated@@25) 3))
(assert (forall (($generated@@26 T@U) ($generated@@27 T@T) ) (! (= ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)) ($generated@@21 $generated@@25 ($generated@@24 $generated@@27 $generated@@26)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@24 $generated@@27 ($generated@@21 $generated@@27 $generated@@26)))
)))
(assert (forall (($generated@@29 Real) ) (! (= ($generated@@28 $generated@@29) $generated@@29)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@28 $generated@@29))
)))
(assert (forall (($generated@@30 Real) ) (! (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))) ($generated@@21 $generated@@25 ($generated@@24 $generated@@6 ($generated@@11 $generated@@30))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 $generated@@30))))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@T) ) (! (= ($generated@@31 $generated@@33 ($generated@@24 $generated@@33 $generated@@32)) $generated@@32)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@24 $generated@@33 $generated@@32))
)))
(assert (forall (($generated@@36 T@U) ) (!  (=> ($generated@@34 $generated@@36 $generated) (and (= ($generated@@24 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36)))) $generated@@36) ($generated@@35 $generated@@6 ($generated@@11 ($generated@@12 ($generated@@31 $generated@@6 $generated@@36))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@34 $generated@@36 $generated))
)))
(assert  (and (and (and (and (forall (($generated@@42 T@T) ($generated@@43 T@T) ($generated@@44 T@U) ($generated@@45 T@U) ($generated@@46 T@U) ) (! (= ($generated@@38 $generated@@42 $generated@@43 ($generated@@39 $generated@@42 $generated@@43 $generated@@45 $generated@@46 $generated@@44) $generated@@46) $generated@@44)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@47 T@T) ($generated@@48 T@T) ($generated@@49 T@U) ($generated@@50 T@U) ($generated@@51 T@U) ($generated@@52 T@U) ) (!  (or (= $generated@@51 $generated@@52) (= ($generated@@38 $generated@@47 $generated@@48 ($generated@@39 $generated@@47 $generated@@48 $generated@@50 $generated@@51 $generated@@49) $generated@@52) ($generated@@38 $generated@@47 $generated@@48 $generated@@50 $generated@@52)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@3 ($generated@@37 $generated@@53 $generated@@54)) 4)
 :qid |ctor:MapType0Type|
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@40 ($generated@@37 $generated@@55 $generated@@56)) $generated@@55)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@37 $generated@@55 $generated@@56))
))) (forall (($generated@@57 T@T) ($generated@@58 T@T) ) (! (= ($generated@@41 ($generated@@37 $generated@@57 $generated@@58)) $generated@@58)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@37 $generated@@57 $generated@@58))
))))
(assert (forall (($generated@@59 T@U) ($generated@@60 T@U) ) (!  (=> ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)) (and (= ($generated@@24 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59)) $generated@@59) ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) ($generated@@31 ($generated@@37 $generated@@25 $generated@@4) $generated@@59) ($generated@@17 $generated@@60))))
 :qid |DafnyPreludebpl.224:15|
 :skolemid |33|
 :pattern ( ($generated@@34 $generated@@59 ($generated@@17 $generated@@60)))
)))
(assert (forall (($generated@@61 T@U) ($generated@@62 T@U) ($generated@@63 T@T) ) (! (= ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62) ($generated@@35 $generated@@63 $generated@@61 $generated@@62))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@34 ($generated@@24 $generated@@63 $generated@@61) $generated@@62))
)))
(assert (forall (($generated@@66 T@U) ($generated@@67 T@U) ($generated@@68 T@U) ($generated@@69 T@T) ) (! (= ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68) ($generated@@65 $generated@@69 $generated@@66 $generated@@67 $generated@@68))
 :qid |DafnyPreludebpl.249:18|
 :skolemid |41|
 :pattern ( ($generated@@64 ($generated@@24 $generated@@69 $generated@@66) $generated@@67 $generated@@68))
)))
(assert (forall (($generated@@70 Real) ) (! ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@35 $generated@@6 ($generated@@11 $generated@@70) $generated))
)))
(assert (forall (($generated@@71 T@U) ($generated@@72 T@U) ) (! (= ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)) (forall (($generated@@73 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73)) ($generated@@34 $generated@@73 $generated@@72))
 :qid |DafnyPreludebpl.277:11|
 :skolemid |51|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@71 $generated@@73))
)))
 :qid |DafnyPreludebpl.275:15|
 :skolemid |52|
 :pattern ( ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@71 ($generated@@17 $generated@@72)))
)))
(assert (forall (($generated@@74 T@U) ($generated@@75 Real) ) (! ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74)
 :qid |DafnyPreludebpl.323:14|
 :skolemid |65|
 :pattern ( ($generated@@65 $generated@@6 ($generated@@11 $generated@@75) $generated $generated@@74))
)))
(assert (forall (($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ) (! (= ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78) (forall (($generated@@79 T@U) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79)) ($generated@@64 $generated@@79 $generated@@77 $generated@@78))
 :qid |DafnyPreludebpl.336:11|
 :skolemid |72|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@76 $generated@@79))
)))
 :qid |DafnyPreludebpl.334:15|
 :skolemid |73|
 :pattern ( ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@76 ($generated@@17 $generated@@77) $generated@@78))
)))
(assert (forall (($generated@@82 T@U) ($generated@@83 Real) ) (!  (=> ($generated@@81 $generated@@82 $generated@@83) (= ($generated@@80 $generated@@82 $generated@@83) (forall (($generated@@84 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@82 ($generated@@24 $generated@@6 ($generated@@11 $generated@@84)))) (<= $generated@@84 $generated@@83))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@82 ($generated@@24 $generated@@6 ($generated@@11 $generated@@84))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@80 $generated@@82 $generated@@83))
)))
(assert (forall (($generated@@85 T@U) ($generated@@86 Real) ) (!  (=> ($generated@@81 $generated@@85 ($generated@@28 $generated@@86)) (= ($generated@@80 $generated@@85 ($generated@@28 $generated@@86)) (forall (($generated@@87 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@85 ($generated@@24 $generated@@6 ($generated@@11 $generated@@87)))) (<= $generated@@87 ($generated@@28 $generated@@86)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |540|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@85 ($generated@@24 $generated@@6 ($generated@@11 $generated@@87))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |541|
 :pattern ( ($generated@@80 $generated@@85 ($generated@@28 $generated@@86)))
)))
(assert (forall (($generated@@88 T@U) ($generated@@89 Real) ) (!  (=> ($generated@@81 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@28 $generated@@89)) (= ($generated@@80 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@28 $generated@@89)) (forall (($generated@@90 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@24 $generated@@6 ($generated@@11 $generated@@90)))) (<= $generated@@90 ($generated@@28 $generated@@89)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |542|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@88 ($generated@@24 $generated@@6 ($generated@@11 $generated@@90))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |543|
 :pattern ( ($generated@@80 ($generated@@21 ($generated@@37 $generated@@25 $generated@@4) $generated@@88) ($generated@@28 $generated@@89)))
)))
(assert  (and (and (and (forall (($generated@@96 T@T) ($generated@@97 T@T) ($generated@@98 T@T) ($generated@@99 T@U) ($generated@@100 T@U) ($generated@@101 T@U) ($generated@@102 T@U) ) (! (= ($generated@@91 $generated@@96 $generated@@97 $generated@@98 ($generated@@95 $generated@@96 $generated@@97 $generated@@98 $generated@@100 $generated@@101 $generated@@102 $generated@@99) $generated@@101 $generated@@102) $generated@@99)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@103 T@T) ($generated@@104 T@T) ($generated@@105 T@T) ($generated@@106 T@U) ($generated@@107 T@U) ($generated@@108 T@U) ($generated@@109 T@U) ($generated@@110 T@U) ($generated@@111 T@U) ) (!  (or (= $generated@@108 $generated@@110) (= ($generated@@91 $generated@@103 $generated@@104 $generated@@105 ($generated@@95 $generated@@103 $generated@@104 $generated@@105 $generated@@107 $generated@@108 $generated@@109 $generated@@106) $generated@@110 $generated@@111) ($generated@@91 $generated@@103 $generated@@104 $generated@@105 $generated@@107 $generated@@110 $generated@@111)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@112 T@T) ($generated@@113 T@T) ($generated@@114 T@T) ($generated@@115 T@U) ($generated@@116 T@U) ($generated@@117 T@U) ($generated@@118 T@U) ($generated@@119 T@U) ($generated@@120 T@U) ) (!  (or (= $generated@@118 $generated@@120) (= ($generated@@91 $generated@@112 $generated@@113 $generated@@114 ($generated@@95 $generated@@112 $generated@@113 $generated@@114 $generated@@116 $generated@@117 $generated@@118 $generated@@115) $generated@@119 $generated@@120) ($generated@@91 $generated@@112 $generated@@113 $generated@@114 $generated@@116 $generated@@119 $generated@@120)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@3 $generated@@92) 5)) (= ($generated@@3 $generated@@93) 6)))
(assert (forall (($generated@@121 T@U) ($generated@@122 T@U) ($generated@@123 T@U) ($generated@@124 Bool) ($generated@@125 T@U) ($generated@@126 T@U) ) (! (= ($generated@@8 ($generated@@91 $generated@@92 $generated@@93 $generated@@4 ($generated@@94 $generated@@121 $generated@@122 $generated@@123 $generated@@124) $generated@@125 $generated@@126))  (=> (and (or (not (= $generated@@125 $generated@@121)) (not true)) ($generated@@8 ($generated@@31 $generated@@4 ($generated@@38 $generated@@93 $generated@@25 ($generated@@38 $generated@@92 ($generated@@37 $generated@@93 $generated@@25) $generated@@122 $generated@@125) $generated@@123)))) $generated@@124))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@91 $generated@@92 $generated@@93 $generated@@4 ($generated@@94 $generated@@121 $generated@@122 $generated@@123 $generated@@124) $generated@@125 $generated@@126))
)))
(assert (forall (($generated@@128 T@U) ($generated@@129 Bool) ($generated@@130 T@U) ) (! (= ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 ($generated@@127 $generated@@128 $generated@@129) $generated@@130))  (and ($generated@@34 $generated@@130 $generated@@128) $generated@@129))
 :qid |DafnyPreludebpl.33:1|
 :skolemid |607|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 ($generated@@127 $generated@@128 $generated@@129) $generated@@130))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@131 () T@U)
(declare-fun $generated@@132 () T@U)
(declare-fun $generated@@133 () Real)
(declare-fun $generated@@134 () Real)
(declare-fun $generated@@135 () Real)
(declare-fun $generated@@136 (T@U) Bool)
(declare-fun $generated@@137 () T@U)
(declare-fun $generated@@138 (T@U) Bool)
(declare-fun $generated@@139 () Real)
(declare-fun $generated@@140 () T@U)
(declare-fun $generated@@141 () T@U)
(declare-fun $generated@@142 () T@U)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.universalFalse_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 10) (let (($generated@@143  (=> (= $generated@@131 ($generated@@127 $generated ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 true))))) (and (=> (= (ControlFlow 0 3) (- 0 5)) ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 1.0)))))) (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 ($generated@@28 1.0))))) (=> ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@131 ($generated@@17 $generated) $generated@@132) (=> (and (and (= $generated@@133 ($generated@@28 0.0)) ($generated@@65 $generated@@6 ($generated@@11 $generated@@133) $generated $generated@@132)) (and ($generated@@81 $generated@@131 ($generated@@28 0.0)) ($generated@@81 $generated@@131 ($generated@@28 0.0)))) (and (=> (= (ControlFlow 0 3) (- 0 4)) (not ($generated@@80 $generated@@131 ($generated@@28 0.0)))) (=> (not ($generated@@80 $generated@@131 ($generated@@28 0.0))) (=> (and (= $generated@@134 ($generated@@28 0.0)) (= $generated@@135 ($generated@@28 0.0))) (=> (and (and (and ($generated@@136 $generated@@137) ($generated@@138 $generated@@137)) (and (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) (and ($generated@@81 $generated@@131 $generated@@135) (=> ($generated@@80 $generated@@131 $generated@@135) ($generated@@81 $generated@@131 $generated@@139)))) (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) ($generated@@80 $generated@@131 $generated@@135)) (and ($generated@@81 $generated@@131 $generated@@139) (and ($generated@@80 $generated@@131 $generated@@139) (forall (($generated@@144 Real) ) (!  (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@144)))) (<= $generated@@144 $generated@@139))
 :qid |sourcekerneldfy.4:12|
 :skolemid |550|
 :pattern ( ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@144))))
))))))) (and (and (=> ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) (and ($generated@@81 $generated@@131 $generated@@135) (=> ($generated@@80 $generated@@131 $generated@@135) (forall (($generated@@145 Real) ) (! ($generated@@81 $generated@@131 $generated@@145)
 :qid |sourcekerneldfy.11:14|
 :skolemid |551|
 :pattern ( ($generated@@80 $generated@@131 $generated@@145))
))))) (=> (and ($generated@@8 ($generated@@38 $generated@@25 $generated@@4 $generated@@131 ($generated@@24 $generated@@6 ($generated@@11 $generated@@134)))) ($generated@@80 $generated@@131 $generated@@135)) (forall (($generated@@146 Real) ) (!  (=> ($generated@@80 $generated@@131 $generated@@146) (<= $generated@@139 $generated@@146))
 :qid |sourcekerneldfy.11:14|
 :skolemid |552|
 :pattern ( ($generated@@80 $generated@@131 $generated@@146))
)))) (and (= $generated@@132 $generated@@137) (= (ControlFlow 0 3) (- 0 2))))) ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 false))))))))))))))
(let (($generated@@147  (=> (and (not ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 true)))) (= (ControlFlow 0 7) 3)) $generated@@143)))
(let (($generated@@148  (=> (and ($generated@@8 ($generated@@21 $generated@@4 ($generated@@7 true))) (= (ControlFlow 0 6) 3)) $generated@@143)))
(let (($generated@@149  (and (=> (= (ControlFlow 0 8) 6) $generated@@148) (=> (= (ControlFlow 0 8) 7) $generated@@147))))
(let (($generated@@150 true))
(let (($generated@@151  (=> (= $generated@@140 ($generated@@94 $generated@@141 $generated@@132 $generated@@2 false)) (and (=> (= (ControlFlow 0 9) 8) $generated@@149) (=> (= (ControlFlow 0 9) 1) $generated@@150)))))
(let (($generated@@152  (=> (and ($generated@@136 $generated@@132) ($generated@@138 $generated@@132)) (=> (and (and (and ($generated@@35 ($generated@@37 $generated@@25 $generated@@4) $generated@@142 ($generated@@17 $generated)) ($generated@@65 ($generated@@37 $generated@@25 $generated@@4) $generated@@142 ($generated@@17 $generated) $generated@@132)) true) (= (ControlFlow 0 10) 9)) $generated@@151))))
$generated@@152))))))))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 3) (- 2))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated (T@T T@U) T@U)
(declare-fun $generated@@0 (T@T) Int)
(declare-fun $generated@@1 () T@T)
(declare-fun $generated@@2 () T@T)
(declare-fun $generated@@3 () T@T)
(declare-fun $generated@@4 (Bool) T@U)
(declare-fun $generated@@5 (T@U) Bool)
(declare-fun $generated@@6 (Int) T@U)
(declare-fun $generated@@7 (T@U) Int)
(declare-fun $generated@@8 (Real) T@U)
(declare-fun $generated@@9 (T@U) Real)
(declare-fun $generated@@15 (T@T T@U) T@U)
(declare-fun $generated@@16 () T@T)
(declare-fun $generated@@19 (Real) Real)
(declare-fun $generated@@22 (T@T T@U) T@U)
(declare-fun $generated@@25 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@26 () T@U)
(declare-fun $generated@@27 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@40 (T@U Real) Bool)
(declare-fun $generated@@41 (T@U Real) Bool)
(declare-fun $generated@@48 (T@T T@T) T@T)
(declare-fun $generated@@49 (T@T) T@T)
(declare-fun $generated@@50 (T@T) T@T)
(declare-fun $generated@@60 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@61 () T@T)
(declare-fun $generated@@62 () T@T)
(declare-fun $generated@@63 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@64 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(assert  (and (and (and (and (and (= ($generated@@0 $generated@@1) 0) (= ($generated@@0 $generated@@2) 1)) (= ($generated@@0 $generated@@3) 2)) (forall (($generated@@10 Bool) ) (! (= ($generated@@5 ($generated@@4 $generated@@10)) $generated@@10)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@4 $generated@@10))
))) (forall (($generated@@11 Int) ) (! (= ($generated@@7 ($generated@@6 $generated@@11)) $generated@@11)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@6 $generated@@11))
))) (forall (($generated@@12 Real) ) (! (= ($generated@@9 ($generated@@8 $generated@@12)) $generated@@12)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@8 $generated@@12))
))))
(assert (forall (($generated@@13 T@U) ($generated@@14 T@T) ) (! (= ($generated $generated@@14 $generated@@13) $generated@@13)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated $generated@@14 $generated@@13))
)))
(assert (= ($generated@@0 $generated@@16) 3))
(assert (forall (($generated@@17 T@U) ($generated@@18 T@T) ) (! (= ($generated@@15 $generated@@18 ($generated $generated@@18 $generated@@17)) ($generated $generated@@16 ($generated@@15 $generated@@18 $generated@@17)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@15 $generated@@18 ($generated $generated@@18 $generated@@17)))
)))
(assert (forall (($generated@@20 Real) ) (! (= ($generated@@19 $generated@@20) $generated@@20)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@19 $generated@@20))
)))
(assert (forall (($generated@@21 Real) ) (! (= ($generated@@15 $generated@@3 ($generated@@8 ($generated@@19 $generated@@21))) ($generated $generated@@16 ($generated@@15 $generated@@3 ($generated@@8 $generated@@21))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@15 $generated@@3 ($generated@@8 ($generated@@19 $generated@@21))))
)))
(assert (forall (($generated@@23 T@U) ($generated@@24 T@T) ) (! (= ($generated@@22 $generated@@24 ($generated@@15 $generated@@24 $generated@@23)) $generated@@23)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@15 $generated@@24 $generated@@23))
)))
(assert  (and (forall (($generated@@28 T@T) ($generated@@29 T@T) ($generated@@30 T@U) ($generated@@31 T@U) ($generated@@32 T@U) ) (! (= ($generated@@25 $generated@@28 $generated@@29 ($generated@@27 $generated@@28 $generated@@29 $generated@@31 $generated@@32 $generated@@30) $generated@@32) $generated@@30)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@33 T@T) ($generated@@34 T@T) ($generated@@35 T@U) ($generated@@36 T@U) ($generated@@37 T@U) ($generated@@38 T@U) ) (!  (or (= $generated@@37 $generated@@38) (= ($generated@@25 $generated@@33 $generated@@34 ($generated@@27 $generated@@33 $generated@@34 $generated@@36 $generated@@37 $generated@@35) $generated@@38) ($generated@@25 $generated@@33 $generated@@34 $generated@@36 $generated@@38)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))))
(assert (forall (($generated@@39 T@U) ) (!  (not ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@26 $generated@@39)))
 :qid |DafnyPreludebpl.837:15|
 :skolemid |155|
 :pattern ( ($generated@@25 $generated@@16 $generated@@1 $generated@@26 $generated@@39))
)))
(assert (forall (($generated@@42 T@U) ($generated@@43 Real) ) (!  (=> ($generated@@41 $generated@@42 $generated@@43) (= ($generated@@40 $generated@@42 $generated@@43) (forall (($generated@@44 Real) ) (!  (=> ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@42 ($generated@@15 $generated@@3 ($generated@@8 $generated@@44)))) (<= $generated@@44 $generated@@43))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@25 $generated@@16 $generated@@1 $generated@@42 ($generated@@15 $generated@@3 ($generated@@8 $generated@@44))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@40 $generated@@42 $generated@@43))
)))
(assert (forall (($generated@@45 T@U) ($generated@@46 Real) ) (!  (=> ($generated@@41 $generated@@45 ($generated@@19 $generated@@46)) (= ($generated@@40 $generated@@45 ($generated@@19 $generated@@46)) (forall (($generated@@47 Real) ) (!  (=> ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@45 ($generated@@15 $generated@@3 ($generated@@8 $generated@@47)))) (<= $generated@@47 ($generated@@19 $generated@@46)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |540|
 :pattern ( ($generated@@25 $generated@@16 $generated@@1 $generated@@45 ($generated@@15 $generated@@3 ($generated@@8 $generated@@47))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |541|
 :pattern ( ($generated@@40 $generated@@45 ($generated@@19 $generated@@46)))
)))
(assert  (and (and (forall (($generated@@51 T@T) ($generated@@52 T@T) ) (! (= ($generated@@0 ($generated@@48 $generated@@51 $generated@@52)) 4)
 :qid |ctor:MapType0Type|
)) (forall (($generated@@53 T@T) ($generated@@54 T@T) ) (! (= ($generated@@49 ($generated@@48 $generated@@53 $generated@@54)) $generated@@53)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@48 $generated@@53 $generated@@54))
))) (forall (($generated@@55 T@T) ($generated@@56 T@T) ) (! (= ($generated@@50 ($generated@@48 $generated@@55 $generated@@56)) $generated@@56)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@48 $generated@@55 $generated@@56))
))))
(assert (forall (($generated@@57 T@U) ($generated@@58 Real) ) (!  (=> ($generated@@41 ($generated ($generated@@48 $generated@@16 $generated@@1) $generated@@57) ($generated@@19 $generated@@58)) (= ($generated@@40 ($generated ($generated@@48 $generated@@16 $generated@@1) $generated@@57) ($generated@@19 $generated@@58)) (forall (($generated@@59 Real) ) (!  (=> ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 ($generated ($generated@@48 $generated@@16 $generated@@1) $generated@@57) ($generated@@15 $generated@@3 ($generated@@8 $generated@@59)))) (<= $generated@@59 ($generated@@19 $generated@@58)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |542|
 :pattern ( ($generated@@25 $generated@@16 $generated@@1 $generated@@57 ($generated@@15 $generated@@3 ($generated@@8 $generated@@59))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |543|
 :pattern ( ($generated@@40 ($generated ($generated@@48 $generated@@16 $generated@@1) $generated@@57) ($generated@@19 $generated@@58)))
)))
(assert  (and (and (and (forall (($generated@@65 T@T) ($generated@@66 T@T) ($generated@@67 T@T) ($generated@@68 T@U) ($generated@@69 T@U) ($generated@@70 T@U) ($generated@@71 T@U) ) (! (= ($generated@@60 $generated@@65 $generated@@66 $generated@@67 ($generated@@64 $generated@@65 $generated@@66 $generated@@67 $generated@@69 $generated@@70 $generated@@71 $generated@@68) $generated@@70 $generated@@71) $generated@@68)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@72 T@T) ($generated@@73 T@T) ($generated@@74 T@T) ($generated@@75 T@U) ($generated@@76 T@U) ($generated@@77 T@U) ($generated@@78 T@U) ($generated@@79 T@U) ($generated@@80 T@U) ) (!  (or (= $generated@@77 $generated@@79) (= ($generated@@60 $generated@@72 $generated@@73 $generated@@74 ($generated@@64 $generated@@72 $generated@@73 $generated@@74 $generated@@76 $generated@@77 $generated@@78 $generated@@75) $generated@@79 $generated@@80) ($generated@@60 $generated@@72 $generated@@73 $generated@@74 $generated@@76 $generated@@79 $generated@@80)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@81 T@T) ($generated@@82 T@T) ($generated@@83 T@T) ($generated@@84 T@U) ($generated@@85 T@U) ($generated@@86 T@U) ($generated@@87 T@U) ($generated@@88 T@U) ($generated@@89 T@U) ) (!  (or (= $generated@@87 $generated@@89) (= ($generated@@60 $generated@@81 $generated@@82 $generated@@83 ($generated@@64 $generated@@81 $generated@@82 $generated@@83 $generated@@85 $generated@@86 $generated@@87 $generated@@84) $generated@@88 $generated@@89) ($generated@@60 $generated@@81 $generated@@82 $generated@@83 $generated@@85 $generated@@88 $generated@@89)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@0 $generated@@61) 5)) (= ($generated@@0 $generated@@62) 6)))
(assert (forall (($generated@@90 T@U) ($generated@@91 T@U) ($generated@@92 T@U) ($generated@@93 Bool) ($generated@@94 T@U) ($generated@@95 T@U) ) (! (= ($generated@@5 ($generated@@60 $generated@@61 $generated@@62 $generated@@1 ($generated@@63 $generated@@90 $generated@@91 $generated@@92 $generated@@93) $generated@@94 $generated@@95))  (=> (and (or (not (= $generated@@94 $generated@@90)) (not true)) ($generated@@5 ($generated@@22 $generated@@1 ($generated@@25 $generated@@62 $generated@@16 ($generated@@25 $generated@@61 ($generated@@48 $generated@@62 $generated@@16) $generated@@91 $generated@@94) $generated@@92)))) $generated@@93))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@60 $generated@@61 $generated@@62 $generated@@1 ($generated@@63 $generated@@90 $generated@@91 $generated@@92 $generated@@93) $generated@@94 $generated@@95))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@96 () T@U)
(declare-fun $generated@@97 () T@U)
(declare-fun $generated@@98 () T@U)
(declare-fun $generated@@99 () T@U)
(declare-fun $generated@@100 () T@U)
(declare-fun $generated@@101 () Real)
(declare-fun $generated@@102 () Real)
(declare-fun $generated@@103 (T@U) Bool)
(declare-fun $generated@@104 () T@U)
(declare-fun $generated@@105 (T@U) Bool)
(declare-fun $generated@@106 () Real)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.emptyValue_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 3) (let (($generated@@107  (=> (and (and (= $generated@@96 ($generated@@63 $generated@@97 $generated@@98 $generated@@99 false)) (= $generated@@100 ($generated ($generated@@48 $generated@@16 $generated@@1) $generated@@26))) (and (= $generated@@101 ($generated@@19 0.0)) (= $generated@@102 ($generated@@19 0.0)))) (=> (and (and (and ($generated@@103 $generated@@104) ($generated@@105 $generated@@104)) (and (=> ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@100 ($generated@@15 $generated@@3 ($generated@@8 $generated@@101)))) (and ($generated@@41 $generated@@100 $generated@@102) (=> ($generated@@40 $generated@@100 $generated@@102) ($generated@@41 $generated@@100 $generated@@106)))) (=> (and ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@100 ($generated@@15 $generated@@3 ($generated@@8 $generated@@101)))) ($generated@@40 $generated@@100 $generated@@102)) (and ($generated@@41 $generated@@100 $generated@@106) (and ($generated@@40 $generated@@100 $generated@@106) (forall (($generated@@108 Real) ) (!  (=> ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@100 ($generated@@15 $generated@@3 ($generated@@8 $generated@@108)))) (<= $generated@@108 $generated@@106))
 :qid |sourcekerneldfy.4:12|
 :skolemid |550|
 :pattern ( ($generated@@25 $generated@@16 $generated@@1 $generated@@100 ($generated@@15 $generated@@3 ($generated@@8 $generated@@108))))
))))))) (and (and (=> ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@100 ($generated@@15 $generated@@3 ($generated@@8 $generated@@101)))) (and ($generated@@41 $generated@@100 $generated@@102) (=> ($generated@@40 $generated@@100 $generated@@102) (forall (($generated@@109 Real) ) (! ($generated@@41 $generated@@100 $generated@@109)
 :qid |sourcekerneldfy.11:14|
 :skolemid |551|
 :pattern ( ($generated@@40 $generated@@100 $generated@@109))
))))) (=> (and ($generated@@5 ($generated@@25 $generated@@16 $generated@@1 $generated@@100 ($generated@@15 $generated@@3 ($generated@@8 $generated@@101)))) ($generated@@40 $generated@@100 $generated@@102)) (forall (($generated@@110 Real) ) (!  (=> ($generated@@40 $generated@@100 $generated@@110) (<= $generated@@106 $generated@@110))
 :qid |sourcekerneldfy.11:14|
 :skolemid |552|
 :pattern ( ($generated@@40 $generated@@100 $generated@@110))
)))) (and (= $generated@@98 $generated@@104) (= (ControlFlow 0 2) (- 0 1))))) (= $generated@@106 ($generated@@19 0.0))))))
(let (($generated@@111  (=> (and (and ($generated@@103 $generated@@98) ($generated@@105 $generated@@98)) (= (ControlFlow 0 3) 2)) $generated@@107)))
$generated@@111)))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 2) (- 1))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
(reset)
(set-option :rlimit 0)
; did a full reset
(reset)
(set-option :print-success false)
(set-info :smt-lib-version 2.6)
(set-option :produce-models true)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
; done setting options


(set-info :category "industrial")
(declare-sort |T@U| 0)
(declare-sort |T@T| 0)
(declare-fun real_pow (Real Real) Real)
(declare-fun UOrdering2 (|T@U| |T@U|) Bool)
(declare-fun UOrdering3 (|T@T| |T@U| |T@U|) Bool)
(declare-fun tickleBool (Bool) Bool)
(assert (and (tickleBool true) (tickleBool false)))
(declare-fun $generated () T@U)
(declare-fun $generated@@0 () T@U)
(declare-fun $generated@@1 () T@U)
(declare-fun $generated@@2 (T@T) Int)
(declare-fun $generated@@3 () T@T)
(declare-fun $generated@@4 () T@T)
(declare-fun $generated@@5 () T@T)
(declare-fun $generated@@6 (Bool) T@U)
(declare-fun $generated@@7 (T@U) Bool)
(declare-fun $generated@@8 (Int) T@U)
(declare-fun $generated@@9 (T@U) Int)
(declare-fun $generated@@10 (Real) T@U)
(declare-fun $generated@@11 (T@U) Real)
(declare-fun $generated@@15 (T@U) T@U)
(declare-fun $generated@@16 (T@T T@U) T@U)
(declare-fun $generated@@19 (T@T T@U) T@U)
(declare-fun $generated@@20 () T@T)
(declare-fun $generated@@23 (Real) Real)
(declare-fun $generated@@26 (T@T T@U) T@U)
(declare-fun $generated@@29 (T@U T@U) Bool)
(declare-fun $generated@@30 (T@T T@U T@U) Bool)
(declare-fun $generated@@36 (T@U Real) Bool)
(declare-fun $generated@@37 (T@U Real) Bool)
(declare-fun $generated@@38 (T@T T@T T@U T@U) T@U)
(declare-fun $generated@@39 (T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@57 (T@T T@T) T@T)
(declare-fun $generated@@58 (T@T) T@T)
(declare-fun $generated@@59 (T@T) T@T)
(declare-fun $generated@@69 (T@T T@T T@T T@U T@U T@U) T@U)
(declare-fun $generated@@70 () T@T)
(declare-fun $generated@@71 () T@T)
(declare-fun $generated@@72 (T@U T@U T@U Bool) T@U)
(declare-fun $generated@@73 (T@T T@T T@T T@U T@U T@U T@U) T@U)
(declare-fun $generated@@105 (T@U Bool) T@U)
(assert  (and (and (and (and (and (= ($generated@@2 $generated@@3) 0) (= ($generated@@2 $generated@@4) 1)) (= ($generated@@2 $generated@@5) 2)) (forall (($generated@@12 Bool) ) (! (= ($generated@@7 ($generated@@6 $generated@@12)) $generated@@12)
 :qid |typeInv:U_2_bool|
 :pattern ( ($generated@@6 $generated@@12))
))) (forall (($generated@@13 Int) ) (! (= ($generated@@9 ($generated@@8 $generated@@13)) $generated@@13)
 :qid |typeInv:U_2_int|
 :pattern ( ($generated@@8 $generated@@13))
))) (forall (($generated@@14 Real) ) (! (= ($generated@@11 ($generated@@10 $generated@@14)) $generated@@14)
 :qid |typeInv:U_2_real|
 :pattern ( ($generated@@10 $generated@@14))
))))
(assert (distinct $generated $generated@@0 $generated@@1)
)
(assert (= ($generated@@15 $generated) $generated@@0))
(assert (forall (($generated@@17 T@U) ($generated@@18 T@T) ) (! (= ($generated@@16 $generated@@18 $generated@@17) $generated@@17)
 :qid |DafnyPreludebpl.106:29|
 :skolemid |15|
 :pattern ( ($generated@@16 $generated@@18 $generated@@17))
)))
(assert (= ($generated@@2 $generated@@20) 3))
(assert (forall (($generated@@21 T@U) ($generated@@22 T@T) ) (! (= ($generated@@19 $generated@@22 ($generated@@16 $generated@@22 $generated@@21)) ($generated@@16 $generated@@20 ($generated@@19 $generated@@22 $generated@@21)))
 :qid |DafnyPreludebpl.107:18|
 :skolemid |16|
 :pattern ( ($generated@@19 $generated@@22 ($generated@@16 $generated@@22 $generated@@21)))
)))
(assert (forall (($generated@@24 Real) ) (! (= ($generated@@23 $generated@@24) $generated@@24)
 :qid |DafnyPreludebpl.115:30|
 :skolemid |19|
 :pattern ( ($generated@@23 $generated@@24))
)))
(assert (forall (($generated@@25 Real) ) (! (= ($generated@@19 $generated@@5 ($generated@@10 ($generated@@23 $generated@@25))) ($generated@@16 $generated@@20 ($generated@@19 $generated@@5 ($generated@@10 $generated@@25))))
 :qid |DafnyPreludebpl.116:15|
 :skolemid |20|
 :pattern ( ($generated@@19 $generated@@5 ($generated@@10 ($generated@@23 $generated@@25))))
)))
(assert (forall (($generated@@27 T@U) ($generated@@28 T@T) ) (! (= ($generated@@26 $generated@@28 ($generated@@19 $generated@@28 $generated@@27)) $generated@@27)
 :qid |DafnyPreludebpl.190:18|
 :weight 3
 :skolemid |26|
 :pattern ( ($generated@@19 $generated@@28 $generated@@27))
)))
(assert (forall (($generated@@31 T@U) ) (!  (=> ($generated@@29 $generated@@31 $generated) (and (= ($generated@@19 $generated@@5 ($generated@@10 ($generated@@11 ($generated@@26 $generated@@5 $generated@@31)))) $generated@@31) ($generated@@30 $generated@@5 ($generated@@10 ($generated@@11 ($generated@@26 $generated@@5 $generated@@31))) $generated)))
 :qid |DafnyPreludebpl.205:15|
 :skolemid |28|
 :pattern ( ($generated@@29 $generated@@31 $generated))
)))
(assert (forall (($generated@@32 T@U) ($generated@@33 T@U) ($generated@@34 T@T) ) (! (= ($generated@@29 ($generated@@19 $generated@@34 $generated@@32) $generated@@33) ($generated@@30 $generated@@34 $generated@@32 $generated@@33))
 :qid |DafnyPreludebpl.246:18|
 :skolemid |40|
 :pattern ( ($generated@@29 ($generated@@19 $generated@@34 $generated@@32) $generated@@33))
)))
(assert (forall (($generated@@35 Real) ) (! ($generated@@30 $generated@@5 ($generated@@10 $generated@@35) $generated)
 :qid |DafnyPreludebpl.261:14|
 :skolemid |43|
 :pattern ( ($generated@@30 $generated@@5 ($generated@@10 $generated@@35) $generated))
)))
(assert  (and (forall (($generated@@40 T@T) ($generated@@41 T@T) ($generated@@42 T@U) ($generated@@43 T@U) ($generated@@44 T@U) ) (! (= ($generated@@38 $generated@@40 $generated@@41 ($generated@@39 $generated@@40 $generated@@41 $generated@@43 $generated@@44 $generated@@42) $generated@@44) $generated@@42)
 :qid |mapAx0:MapType0Select|
 :weight 0
)) (forall (($generated@@45 T@T) ($generated@@46 T@T) ($generated@@47 T@U) ($generated@@48 T@U) ($generated@@49 T@U) ($generated@@50 T@U) ) (!  (or (= $generated@@49 $generated@@50) (= ($generated@@38 $generated@@45 $generated@@46 ($generated@@39 $generated@@45 $generated@@46 $generated@@48 $generated@@49 $generated@@47) $generated@@50) ($generated@@38 $generated@@45 $generated@@46 $generated@@48 $generated@@50)))
 :qid |mapAx1:MapType0Select:0|
 :weight 0
))))
(assert (forall (($generated@@51 T@U) ($generated@@52 Real) ) (!  (=> ($generated@@37 $generated@@51 $generated@@52) (= ($generated@@36 $generated@@51 $generated@@52) (forall (($generated@@53 Real) ) (!  (=> ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@51 ($generated@@19 $generated@@5 ($generated@@10 $generated@@53)))) (<= $generated@@53 $generated@@52))
 :qid |sourcekerneldfy.4:12|
 :skolemid |538|
 :pattern ( ($generated@@38 $generated@@20 $generated@@3 $generated@@51 ($generated@@19 $generated@@5 ($generated@@10 $generated@@53))))
))))
 :qid |sourcekerneldfy.3:25|
 :skolemid |539|
 :pattern ( ($generated@@36 $generated@@51 $generated@@52))
)))
(assert (forall (($generated@@54 T@U) ($generated@@55 Real) ) (!  (=> ($generated@@37 $generated@@54 ($generated@@23 $generated@@55)) (= ($generated@@36 $generated@@54 ($generated@@23 $generated@@55)) (forall (($generated@@56 Real) ) (!  (=> ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@54 ($generated@@19 $generated@@5 ($generated@@10 $generated@@56)))) (<= $generated@@56 ($generated@@23 $generated@@55)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |540|
 :pattern ( ($generated@@38 $generated@@20 $generated@@3 $generated@@54 ($generated@@19 $generated@@5 ($generated@@10 $generated@@56))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |541|
 :pattern ( ($generated@@36 $generated@@54 ($generated@@23 $generated@@55)))
)))
(assert  (and (and (forall (($generated@@60 T@T) ($generated@@61 T@T) ) (! (= ($generated@@2 ($generated@@57 $generated@@60 $generated@@61)) 4)
 :qid |ctor:MapType0Type|
)) (forall (($generated@@62 T@T) ($generated@@63 T@T) ) (! (= ($generated@@58 ($generated@@57 $generated@@62 $generated@@63)) $generated@@62)
 :qid |typeInv:MapType0TypeInv0|
 :pattern ( ($generated@@57 $generated@@62 $generated@@63))
))) (forall (($generated@@64 T@T) ($generated@@65 T@T) ) (! (= ($generated@@59 ($generated@@57 $generated@@64 $generated@@65)) $generated@@65)
 :qid |typeInv:MapType0TypeInv1|
 :pattern ( ($generated@@57 $generated@@64 $generated@@65))
))))
(assert (forall (($generated@@66 T@U) ($generated@@67 Real) ) (!  (=> ($generated@@37 ($generated@@16 ($generated@@57 $generated@@20 $generated@@3) $generated@@66) ($generated@@23 $generated@@67)) (= ($generated@@36 ($generated@@16 ($generated@@57 $generated@@20 $generated@@3) $generated@@66) ($generated@@23 $generated@@67)) (forall (($generated@@68 Real) ) (!  (=> ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 ($generated@@16 ($generated@@57 $generated@@20 $generated@@3) $generated@@66) ($generated@@19 $generated@@5 ($generated@@10 $generated@@68)))) (<= $generated@@68 ($generated@@23 $generated@@67)))
 :qid |sourcekerneldfy.4:12|
 :skolemid |542|
 :pattern ( ($generated@@38 $generated@@20 $generated@@3 $generated@@66 ($generated@@19 $generated@@5 ($generated@@10 $generated@@68))))
))))
 :qid |sourcekerneldfy.3:25|
 :weight 3
 :skolemid |543|
 :pattern ( ($generated@@36 ($generated@@16 ($generated@@57 $generated@@20 $generated@@3) $generated@@66) ($generated@@23 $generated@@67)))
)))
(assert  (and (and (and (forall (($generated@@74 T@T) ($generated@@75 T@T) ($generated@@76 T@T) ($generated@@77 T@U) ($generated@@78 T@U) ($generated@@79 T@U) ($generated@@80 T@U) ) (! (= ($generated@@69 $generated@@74 $generated@@75 $generated@@76 ($generated@@73 $generated@@74 $generated@@75 $generated@@76 $generated@@78 $generated@@79 $generated@@80 $generated@@77) $generated@@79 $generated@@80) $generated@@77)
 :qid |mapAx0:MapType1Select|
 :weight 0
)) (and (forall (($generated@@81 T@T) ($generated@@82 T@T) ($generated@@83 T@T) ($generated@@84 T@U) ($generated@@85 T@U) ($generated@@86 T@U) ($generated@@87 T@U) ($generated@@88 T@U) ($generated@@89 T@U) ) (!  (or (= $generated@@86 $generated@@88) (= ($generated@@69 $generated@@81 $generated@@82 $generated@@83 ($generated@@73 $generated@@81 $generated@@82 $generated@@83 $generated@@85 $generated@@86 $generated@@87 $generated@@84) $generated@@88 $generated@@89) ($generated@@69 $generated@@81 $generated@@82 $generated@@83 $generated@@85 $generated@@88 $generated@@89)))
 :qid |mapAx1:MapType1Select:0|
 :weight 0
)) (forall (($generated@@90 T@T) ($generated@@91 T@T) ($generated@@92 T@T) ($generated@@93 T@U) ($generated@@94 T@U) ($generated@@95 T@U) ($generated@@96 T@U) ($generated@@97 T@U) ($generated@@98 T@U) ) (!  (or (= $generated@@96 $generated@@98) (= ($generated@@69 $generated@@90 $generated@@91 $generated@@92 ($generated@@73 $generated@@90 $generated@@91 $generated@@92 $generated@@94 $generated@@95 $generated@@96 $generated@@93) $generated@@97 $generated@@98) ($generated@@69 $generated@@90 $generated@@91 $generated@@92 $generated@@94 $generated@@97 $generated@@98)))
 :qid |mapAx1:MapType1Select:1|
 :weight 0
)))) (= ($generated@@2 $generated@@70) 5)) (= ($generated@@2 $generated@@71) 6)))
(assert (forall (($generated@@99 T@U) ($generated@@100 T@U) ($generated@@101 T@U) ($generated@@102 Bool) ($generated@@103 T@U) ($generated@@104 T@U) ) (! (= ($generated@@7 ($generated@@69 $generated@@70 $generated@@71 $generated@@3 ($generated@@72 $generated@@99 $generated@@100 $generated@@101 $generated@@102) $generated@@103 $generated@@104))  (=> (and (or (not (= $generated@@103 $generated@@99)) (not true)) ($generated@@7 ($generated@@26 $generated@@3 ($generated@@38 $generated@@71 $generated@@20 ($generated@@38 $generated@@70 ($generated@@57 $generated@@71 $generated@@20) $generated@@100 $generated@@103) $generated@@101)))) $generated@@102))
 :qid |DafnyPreludebpl.161:1|
 :skolemid |606|
 :pattern ( ($generated@@69 $generated@@70 $generated@@71 $generated@@3 ($generated@@72 $generated@@99 $generated@@100 $generated@@101 $generated@@102) $generated@@103 $generated@@104))
)))
(assert (forall (($generated@@106 T@U) ($generated@@107 Bool) ($generated@@108 T@U) ) (! (= ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 ($generated@@105 $generated@@106 $generated@@107) $generated@@108))  (and ($generated@@29 $generated@@108 $generated@@106) $generated@@107))
 :qid |DafnyPreludebpl.33:1|
 :skolemid |607|
 :pattern ( ($generated@@38 $generated@@20 $generated@@3 ($generated@@105 $generated@@106 $generated@@107) $generated@@108))
)))
(push 1)
(declare-fun ControlFlow (Int Int) Int)
(declare-fun $generated@@109 () T@U)
(declare-fun $generated@@110 () Real)
(declare-fun $generated@@111 () Real)
(declare-fun $generated@@112 (T@U) Bool)
(declare-fun $generated@@113 () T@U)
(declare-fun $generated@@114 (T@U) Bool)
(declare-fun $generated@@115 () Real)
(declare-fun $generated@@116 () T@U)
(declare-fun $generated@@117 () T@U)
(declare-fun $generated@@118 () T@U)
(set-info :boogie-vc-id Impl$$RealCompletenessProbe.__default.universalValue_split0)
(set-option :timeout 30000)
(set-option :rlimit 16000000)
(set-option :auto_config false)
(set-option :type_check true)
(set-option :smt.qi.eager_threshold 44)
(set-option :smt.delay_units true)
(set-option :model_evaluator.completion true)
(set-option :model.completion true)
(set-option :model.compact false)
(set-option :smt.case_split 3)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.mbqi false)
(set-option :model.v2 true)
(set-option :pp.bv_literals false)
(set-option :smt.refine_inj_axioms false)
(set-option :smt.arith.solver 2)
(assert (not
 (=> (= (ControlFlow 0 0) 8) (let (($generated@@119  (=> (= $generated@@109 ($generated@@105 $generated ($generated@@7 ($generated@@16 $generated@@3 ($generated@@6 true))))) (=> (and (= $generated@@110 ($generated@@23 0.0)) (= $generated@@111 ($generated@@23 0.0))) (=> (and (and (and ($generated@@112 $generated@@113) ($generated@@114 $generated@@113)) (and (=> ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@109 ($generated@@19 $generated@@5 ($generated@@10 $generated@@110)))) (and ($generated@@37 $generated@@109 $generated@@111) (=> ($generated@@36 $generated@@109 $generated@@111) ($generated@@37 $generated@@109 $generated@@115)))) (=> (and ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@109 ($generated@@19 $generated@@5 ($generated@@10 $generated@@110)))) ($generated@@36 $generated@@109 $generated@@111)) (and ($generated@@37 $generated@@109 $generated@@115) (and ($generated@@36 $generated@@109 $generated@@115) (forall (($generated@@120 Real) ) (!  (=> ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@109 ($generated@@19 $generated@@5 ($generated@@10 $generated@@120)))) (<= $generated@@120 $generated@@115))
 :qid |sourcekerneldfy.4:12|
 :skolemid |550|
 :pattern ( ($generated@@38 $generated@@20 $generated@@3 $generated@@109 ($generated@@19 $generated@@5 ($generated@@10 $generated@@120))))
))))))) (and (and (=> ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@109 ($generated@@19 $generated@@5 ($generated@@10 $generated@@110)))) (and ($generated@@37 $generated@@109 $generated@@111) (=> ($generated@@36 $generated@@109 $generated@@111) (forall (($generated@@121 Real) ) (! ($generated@@37 $generated@@109 $generated@@121)
 :qid |sourcekerneldfy.11:14|
 :skolemid |551|
 :pattern ( ($generated@@36 $generated@@109 $generated@@121))
))))) (=> (and ($generated@@7 ($generated@@38 $generated@@20 $generated@@3 $generated@@109 ($generated@@19 $generated@@5 ($generated@@10 $generated@@110)))) ($generated@@36 $generated@@109 $generated@@111)) (forall (($generated@@122 Real) ) (!  (=> ($generated@@36 $generated@@109 $generated@@122) (<= $generated@@115 $generated@@122))
 :qid |sourcekerneldfy.11:14|
 :skolemid |552|
 :pattern ( ($generated@@36 $generated@@109 $generated@@122))
)))) (and (= $generated@@116 $generated@@113) (= (ControlFlow 0 3) (- 0 2))))) (= $generated@@115 ($generated@@23 0.0)))))))
(let (($generated@@123  (=> (and (not ($generated@@7 ($generated@@16 $generated@@3 ($generated@@6 true)))) (= (ControlFlow 0 5) 3)) $generated@@119)))
(let (($generated@@124  (=> (and ($generated@@7 ($generated@@16 $generated@@3 ($generated@@6 true))) (= (ControlFlow 0 4) 3)) $generated@@119)))
(let (($generated@@125  (and (=> (= (ControlFlow 0 6) 4) $generated@@124) (=> (= (ControlFlow 0 6) 5) $generated@@123))))
(let (($generated@@126 true))
(let (($generated@@127  (=> (= $generated@@117 ($generated@@72 $generated@@118 $generated@@116 $generated@@1 false)) (and (=> (= (ControlFlow 0 7) 6) $generated@@125) (=> (= (ControlFlow 0 7) 1) $generated@@126)))))
(let (($generated@@128  (=> (and (and ($generated@@112 $generated@@116) ($generated@@114 $generated@@116)) (= (ControlFlow 0 8) 7)) $generated@@127)))
$generated@@128))))))))
))
(check-sat)
(get-info :reason-unknown)
(get-info :rlimit)
(get-model)
(assert (not (= (ControlFlow 0 3) (- 2))))
(check-sat)
(get-info :rlimit)
(pop 1)
; Invalid
